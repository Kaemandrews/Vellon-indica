
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { Toaster } from "@/components/ui/toaster";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import HomePage from "@/pages/HomePage";
import IndicatePage from "@/pages/IndicatePage";
import PlansPage from "@/pages/PlansPage";

function App() {
  return (
    <Router>
      <div className="flex min-h-screen flex-col bg-gradient-to-br from-gray-50 to-green-50">
        <Header />
        <main className="flex-1">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/indicar" element={<IndicatePage />} />
            <Route path="/planos" element={<PlansPage />} />
          </Routes>
        </main>
        <Footer />
        <Toaster />
      </div>
    </Router>
  );
}

export default App;
