
import React from "react";

const ReferralHistory = () => {
  return (
    <div>
      {/* Este componente não é mais usado no novo design, mas o arquivo é mantido para evitar erros de importação caso seja referenciado em algum lugar não atualizado. */}
      {/* Você pode remover este arquivo se tiver certeza de que não está sendo importado em nenhum lugar. */}
    </div>
  );
};

export default ReferralHistory;
