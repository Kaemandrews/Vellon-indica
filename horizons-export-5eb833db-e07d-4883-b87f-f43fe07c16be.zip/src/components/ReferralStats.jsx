
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Users, Gift, TrendingUp } from "lucide-react";
import { motion } from "framer-motion";

const StatCard = ({ icon, title, value, description }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="referral-card"
    >
      <Card className="h-full">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-sm font-medium">{title}</CardTitle>
          <div className="rounded-full bg-primary/10 p-2 text-primary">
            {icon}
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{value}</div>
          <p className="text-xs text-muted-foreground">{description}</p>
        </CardContent>
      </Card>
    </motion.div>
  );
};

const ReferralStats = ({ stats }) => {
  const { referrals, rewards, nextReward, progress } = stats;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <StatCard
          icon={<Users size={18} />}
          title="Total de Indicações"
          value={referrals}
          description="Pessoas que usaram seu código"
        />
        <StatCard
          icon={<Gift size={18} />}
          title="Recompensas Ganhas"
          value={rewards}
          description="Valor total em recompensas"
        />
        <StatCard
          icon={<TrendingUp size={18} />}
          title="Próxima Recompensa"
          value={nextReward}
          description={`Em ${5 - (progress % 5)} indicações`}
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Progresso para Próxima Recompensa</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Progress value={progress % 5 * 20} className="h-2" />
            <div className="flex justify-between text-xs">
              <span>{progress % 5} de 5 indicações</span>
              <span>{progress % 5 * 20}% completo</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ReferralStats;
