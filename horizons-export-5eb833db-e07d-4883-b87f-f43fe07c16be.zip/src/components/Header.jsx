
import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Menu, X, Zap, Info, MapPin, Briefcase, FileText, Package } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogDescription,
} from "@/components/ui/dialog";

const RulesModal = () => (
  <DialogContent className="sm:max-w-md">
    <DialogHeader>
      <DialogTitle className="flex items-center gap-2 text-green-600">
        <FileText size={24} /> Regras da Promoção "Indica Aí"
      </DialogTitle>
      <DialogDescription>
        Leia atentamente as regras para participar e ganhar prêmios.
      </DialogDescription>
    </DialogHeader>
    <div className="grid gap-4 py-4">
      <ul className="list-none space-y-3 text-sm text-gray-700">
        <li className="flex items-start gap-2">
          <span className="mt-1 block h-2 w-2 flex-shrink-0 rounded-full bg-green-500"></span>
          <span>A promoção 'Vellon Indica' é válida por tempo limitado. Consulte o regulamento.</span>
        </li>
        <li className="flex items-start gap-2">
          <span className="mt-1 block h-2 w-2 flex-shrink-0 rounded-full bg-green-500"></span>
          <span>Para cada indicação válida, o indicador receberá prêmio no Valor de R$ 50,00.</span>
        </li>
        <li className="flex items-start gap-2">
          <span className="mt-1 block h-2 w-2 flex-shrink-0 rounded-full bg-green-500"></span>
          <span>Uma indicação é considerada válida quando o indicado contrata qualquer serviço.</span>
        </li>
        <li className="flex items-start gap-2">
          <span className="mt-1 block h-2 w-2 flex-shrink-0 rounded-full bg-green-500"></span>
          <span>Os prêmios serão pagos via Pix em até 15 dias úteis após a validação da indicação.</span>
        </li>
        <li className="flex items-start gap-2">
          <span className="mt-1 block h-2 w-2 flex-shrink-0 rounded-full bg-green-500"></span>
          <span>Não há limite para o número de indicações, indique quantos amigos quiser!</span>
        </li>
      </ul>
    </div>
  </DialogContent>
);

const CitiesModal = () => (
  <DialogContent className="sm:max-w-sm">
    <DialogHeader>
      <DialogTitle className="flex items-center gap-2 text-green-600">
        <MapPin size={24} /> Cidades Participantes
      </DialogTitle>
      <DialogDescription>
        Confira abaixo as cidades onde nossa promoção de indicação está ativa.
      </DialogDescription>
    </DialogHeader>
    <div className="grid gap-3 py-4">
      {["Santa Izabel", "Santo Antônio do Tauá", "Castanhal", "Curuçá", "Marapanim", "Bujaru", "Nova Timboteua"].map((city) => (
        <div key={city} className="flex items-center gap-3 rounded-md bg-green-50 p-3">
          <MapPin size={18} className="text-green-500" />
          <span className="text-sm font-medium text-gray-700">{city}</span>
        </div>
      ))}
    </div>
  </DialogContent>
);

const PartnersModal = () => (
  <DialogContent className="sm:max-w-lg">
    <DialogHeader>
      <DialogTitle className="flex items-center gap-2 text-green-600">
        <Briefcase size={24} /> Empresas Parceiras
      </DialogTitle>
      <DialogDescription>
        Conheça as empresas que apoiam nosso programa de indicação.
      </DialogDescription>
    </DialogHeader>
    <div className="grid grid-cols-2 gap-4 py-4 sm:grid-cols-3">
      <div className="flex flex-col items-center justify-center rounded-lg border bg-gray-50 p-4 shadow-sm transition-all hover:shadow-md">
        <img  class="h-16 w-auto object-contain" alt="Logo Empresa Parceira 1" src="https://images.unsplash.com/photo-1537452881174-ffd33c48c682" />
        <p className="mt-2 text-xs font-medium text-gray-600">Parceiro Tech</p>
      </div>
      <div className="flex flex-col items-center justify-center rounded-lg border bg-gray-50 p-4 shadow-sm transition-all hover:shadow-md">
        <img  class="h-16 w-auto object-contain" alt="Logo Empresa Parceira 2" src="https://images.unsplash.com/photo-1698306611028-70d5bf3e0a96" />
        <p className="mt-2 text-xs font-medium text-gray-600">Serviços Locais</p>
      </div>
      <div className="flex flex-col items-center justify-center rounded-lg border bg-gray-50 p-4 shadow-sm transition-all hover:shadow-md">
        <img  class="h-16 w-auto object-contain" alt="Logo Empresa Parceira 3" src="https://images.unsplash.com/photo-1637666495020-0740caec198a" />
        <p className="mt-2 text-xs font-medium text-gray-600">Varejo Amigo</p>
      </div>
      <div className="flex flex-col items-center justify-center rounded-lg border bg-gray-50 p-4 shadow-sm transition-all hover:shadow-md">
        <img  class="h-16 w-auto object-contain" alt="Logo Empresa Parceira 4" src="https://images.unsplash.com/photo-1697564265108-446bd9988284" />
        <p className="mt-2 text-xs font-medium text-gray-600">Diversão Garantida</p>
      </div>
      <div className="flex flex-col items-center justify-center rounded-lg border bg-gray-50 p-4 shadow-sm transition-all hover:shadow-md">
        <img  class="h-16 w-auto object-contain" alt="Logo Empresa Parceira 5" src="https://images.unsplash.com/photo-1685722624202-c84f60443677" />
        <p className="mt-2 text-xs font-medium text-gray-600">Educa Mais</p>
      </div>
       <div className="flex flex-col items-center justify-center rounded-lg border bg-gray-50 p-4 shadow-sm transition-all hover:shadow-md">
        <img  class="h-16 w-auto object-contain" alt="Logo Empresa Parceira 6" src="https://images.unsplash.com/photo-1630506952233-c77e33fb2bb9" />
        <p className="mt-2 text-xs font-medium text-gray-600">Sabor & Cia</p>
      </div>
    </div>
  </DialogContent>
);


const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const navLinks = [
    { to: "/planos", text: "Planos", icon: <Package size={18} /> },
    { modal: <RulesModal />, text: "Regras", icon: <FileText size={18} /> },
    { modal: <CitiesModal />, text: "Cidades Participantes", icon: <MapPin size={18} /> },
    { modal: <PartnersModal />, text: "Empresas Parceiras", icon: <Briefcase size={18} /> },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-green-500 text-white shadow-lg">
      <div className="container mx-auto flex h-20 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="flex items-center gap-2"
          >
            <Zap size={32} className="text-yellow-300" />
            <span className="text-2xl font-bold tracking-tight">Vellon Indica</span>
          </motion.div>
        </Link>

        <nav className="hidden items-center gap-2 md:flex">
          {navLinks.map((link, index) => (
            link.to ? (
              <Link
                key={index}
                to={link.to}
                className="flex items-center gap-1.5 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-green-600 hover:text-white"
              >
                {link.icon} {link.text}
              </Link>
            ) : (
              <Dialog key={index}>
                <DialogTrigger asChild>
                  <Button variant="ghost" className="flex items-center gap-1.5 px-3 py-2 text-sm font-medium text-white transition-colors hover:bg-green-600 hover:text-white">
                    {link.icon} {link.text}
                  </Button>
                </DialogTrigger>
                {link.modal}
              </Dialog>
            )
          ))}
        </nav>

        <button
          className="inline-flex items-center justify-center rounded-md p-2 text-white transition-colors hover:bg-green-600 md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {isMenuOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          className="border-t border-green-600 bg-green-500 md:hidden"
        >
          <nav className="container mx-auto flex flex-col space-y-1 px-2 py-3">
            {navLinks.map((link, index) => (
              link.to ? (
                <Link
                  key={index}
                  to={link.to}
                  className="flex items-center gap-2 rounded-md px-3 py-2 text-base font-medium transition-colors hover:bg-green-600"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.icon} {link.text}
                </Link>
              ) : (
                <Dialog key={index}>
                  <DialogTrigger asChild>
                    <Button variant="ghost" className="flex w-full items-center justify-start gap-2 px-3 py-2 text-base font-medium text-white transition-colors hover:bg-green-600 hover:text-white">
                      {link.icon} {link.text}
                    </Button>
                  </DialogTrigger>
                  {link.modal}
                </Dialog>
              )
            ))}
          </nav>
        </motion.div>
      )}
    </header>
  );
};

export default Header;
