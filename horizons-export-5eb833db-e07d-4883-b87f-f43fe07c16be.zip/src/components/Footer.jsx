
import React from "react";
import { Separator } from "@/components/ui/separator";
import { Zap } from "lucide-react";

const Footer = () => {
  return (
    <footer className="mt-auto border-t bg-gray-100 py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 gap-8 text-center md:grid-cols-3 md:text-left">
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center justify-center gap-2 md:justify-start">
              <Zap size={24} className="text-green-500" />
              <span className="text-xl font-bold text-gray-800">Vellon Indica</span>
            </div>
            <p className="text-sm text-gray-600">
              O melhor programa de indicação para você e seus amigos.
            </p>
          </div>
          
          <div className="md:col-span-1">
            <h3 className="mb-3 text-sm font-semibold uppercase text-gray-700">Links Úteis</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-gray-600 transition-colors hover:text-green-500">
                  Termos e Condições
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600 transition-colors hover:text-green-500">
                  Política de Privacidade
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-600 transition-colors hover:text-green-500">
                  FAQ
                </a>
              </li>
            </ul>
          </div>

          <div className="md:col-span-1">
            <h3 className="mb-3 text-sm font-semibold uppercase text-gray-700">Contato</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="mailto:contato@vellonindica.com.br" className="text-gray-600 transition-colors hover:text-green-500">
                  contato@vellonindica.com.br
                </a>
              </li>
              <li>
                <span className="text-gray-600">(91) 99988-7733</span>
              </li>
            </ul>
          </div>
        </div>
        <Separator className="my-8 bg-gray-300" />
        <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
          <p className="text-center text-sm text-gray-500">
            &copy; {new Date().getFullYear()} Vellon Indica. Todos os direitos reservados.
          </p>
          <div className="flex items-center gap-4">
            <a href="#" className="text-gray-500 transition-colors hover:text-green-500">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
              </svg>
              <span className="sr-only">Facebook</span>
            </a>
            <a href="#" className="text-gray-500 transition-colors hover:text-green-500">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
              </svg>
              <span className="sr-only">Instagram</span>
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
