
import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Users, Award, Gift } from "lucide-react";

const HomePage = () => {
  const navigate = useNavigate();

  const handleIndicateNow = () => {
    navigate("/indicar");
  };

  return (
    <div className="container mx-auto flex min-h-[calc(100vh-10rem)] flex-col items-center justify-center px-4 py-12 text-center">
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="mb-8"
      >
        <Gift size={80} className="mx-auto text-green-500" />
        <h1 className="mt-6 text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl md:text-6xl">
          Bem-vindo ao Nosso <span className="text-green-500">Programa de Indicação!</span>
        </h1>
        <p className="mt-6 max-w-2xl text-lg leading-8 text-gray-600">
          Indique seus amigos e ganhe prêmios incríveis! É fácil, rápido e vantajoso. Transforme suas conexões em recompensas.
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.3 }}
        className="mb-12 grid w-full max-w-3xl grid-cols-1 gap-8 md:grid-cols-2"
      >
        <Card className="text-left shadow-lg transition-all hover:shadow-xl">
          <CardHeader className="flex-row items-center gap-4">
            <div className="rounded-full bg-green-100 p-3">
              <Users size={24} className="text-green-600" />
            </div>
            <CardTitle className="text-xl">Indique Amigos</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Compartilhe com quantas pessoas quiser. Quanto mais amigos você indicar, mais chances de ganhar!
            </CardDescription>
          </CardContent>
        </Card>
        <Card className="text-left shadow-lg transition-all hover:shadow-xl">
          <CardHeader className="flex-row items-center gap-4">
            <div className="rounded-full bg-green-100 p-3">
              <Award size={24} className="text-green-600" />
            </div>
            <CardTitle className="text-xl">Ganhe Prêmios</CardTitle>
          </CardHeader>
          <CardContent>
            <CardDescription>
              Receba recompensas por cada indicação qualificada. Consulte as regras para saber mais sobre os prêmios.
            </CardDescription>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.6, ease: "easeOut" }}
      >
        <Button
          size="lg"
          onClick={handleIndicateNow}
          className="rounded-full bg-green-500 px-10 py-6 text-lg font-semibold text-white shadow-lg transition-all hover:bg-green-600 hover:shadow-xl focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2"
        >
          Indicar Agora
        </Button>
      </motion.div>
    </div>
  );
};

export default HomePage;
