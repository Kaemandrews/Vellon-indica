
import React from "react";

const Dashboard = () => {
  return (
    <div>
      {/* Esta página não é mais usada no novo design, mas o arquivo é mantido para evitar erros de importação caso seja referenciado em algum lugar não atualizado. */}
      {/* Você pode remover este arquivo se tiver certeza de que não está sendo importado em nenhum lugar. */}
      <p>Página de Dashboard Antiga - Não utilizada</p>
    </div>
  );
};

export default Dashboard;
