
import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, Wifi, Tv, Film, Gamepad2, Music2, Smile, Package } from "lucide-react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";

const plansData = [
  {
    name: "Internet 300 Mega",
    price: "79,90",
    icon: <Wifi size={32} className="text-green-500" />,
    features: ["Velocidade de 300 Mega", "Ideal para navegação e streaming"],
    bgColor: "bg-green-50",
    textColor: "text-green-700",
    borderColor: "border-green-500",
  },
  {
    name: "Internet 500 Mega + Deezer",
    price: "109,90",
    icon: <Music2 size={32} className="text-purple-500" />,
    features: ["Velocidade de 500 Mega", "Acesso ao Deezer Premium", "Música ilimitada"],
    bgColor: "bg-purple-50",
    textColor: "text-purple-700",
    borderColor: "border-purple-500",
  },
  {
    name: "Internet 500 Mega + Globoplay (com anúncios)",
    price: "129,90",
    icon: <Tv size={32} className="text-blue-500" />,
    features: ["Velocidade de 500 Mega", "Acesso ao Globoplay com anúncios", "Filmes e séries"],
    bgColor: "bg-blue-50",
    textColor: "text-blue-700",
    borderColor: "border-blue-500",
  },
  {
    name: "Internet 500 Mega + Brasileirão Premiere",
    price: "149,90",
    icon: <Gamepad2 size={32} className="text-orange-500" />,
    features: ["Velocidade de 500 Mega", "Acesso ao Brasileirão Premiere", "Jogos ao vivo"],
    bgColor: "bg-orange-50",
    textColor: "text-orange-700",
    borderColor: "border-orange-500",
  },
  {
    name: "Internet 500 Mega + Globoplay (sem anúncios)",
    price: "169,90",
    icon: <Film size={32} className="text-red-500" />,
    features: ["Velocidade de 500 Mega", "Acesso ao Globoplay sem anúncios", "Conteúdo exclusivo"],
    bgColor: "bg-red-50",
    textColor: "text-red-700",
    borderColor: "border-red-500",
  },
  {
    name: "Internet 700 Mega",
    price: "109,90",
    icon: <Wifi size={32} className="text-teal-500" />,
    features: ["Velocidade de 700 Mega", "Ultra velocidade para múltiplos dispositivos"],
    bgColor: "bg-teal-50",
    textColor: "text-teal-700",
    borderColor: "border-teal-500",
  },
  {
    name: "Internet 500 Mega + Playkids+",
    price: "109,90",
    icon: <Smile size={32} className="text-yellow-500" />,
    features: ["Velocidade de 500 Mega", "Acesso ao Playkids+", "Diversão para crianças"],
    bgColor: "bg-yellow-50",
    textColor: "text-yellow-700",
    borderColor: "border-yellow-500",
  },
  {
    name: "Internet 700 Mega (Alternativo)",
    price: "119,90",
    icon: <Wifi size={32} className="text-indigo-500" />,
    features: ["Velocidade de 700 Mega", "Conexão estável e potente"],
    bgColor: "bg-indigo-50",
    textColor: "text-indigo-700",
    borderColor: "border-indigo-500",
  },
  {
    name: "Internet 600 MB + Max",
    price: "129,90",
    icon: <Film size={32} className="text-pink-500" />,
    features: ["Velocidade de 600 Mega", "Acesso ao Max (HBO Max)", "Grandes sucessos do cinema e séries"],
    bgColor: "bg-pink-50",
    textColor: "text-pink-700",
    borderColor: "border-pink-500",
  },
];

const PlansPage = () => {
  const navigate = useNavigate();

  const handleIndicateNow = () => {
    navigate("/indicar");
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
        className="mb-12 text-center"
      >
        <div className="mx-auto mb-4 inline-block rounded-full bg-green-100 p-3">
          <Package size={40} className="text-green-500" />
        </div>
        <h1 className="text-4xl font-bold tracking-tight text-gray-800 sm:text-5xl">
          Nossos Planos de <span className="text-green-500">Internet</span>
        </h1>
        <p className="mt-4 max-w-xl mx-auto text-lg text-gray-600">
          Escolha o plano ideal para você e sua família. Conecte-se com a melhor velocidade!
        </p>
      </motion.div>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
        {plansData.map((plan, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <Card className={`flex h-full flex-col overflow-hidden rounded-xl shadow-lg transition-all hover:shadow-2xl ${plan.bgColor} border-2 ${plan.borderColor}`}>
              <CardHeader className={`p-6 ${plan.textColor}`}>
                <div className="mb-4 flex items-center justify-center rounded-lg bg-white p-3 shadow-md w-16 h-16 mx-auto">
                  {plan.icon}
                </div>
                <CardTitle className={`text-2xl font-semibold text-center ${plan.textColor}`}>{plan.name}</CardTitle>
                <CardDescription className="mt-2 text-center text-4xl font-bold">
                  R$ <span className={plan.textColor}>{plan.price}</span>
                  <span className="text-sm font-normal text-gray-500">/mês</span>
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-1 flex-col justify-between p-6">
                <ul className="mb-6 space-y-2">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-center text-sm text-gray-700">
                      <CheckCircle size={16} className={`mr-2 flex-shrink-0 ${plan.textColor}`} />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Button 
                  onClick={handleIndicateNow}
                  className={`w-full bg-green-500 text-white hover:bg-green-600 font-semibold py-3 transition-transform hover:scale-105`}
                >
                  Indicar este Plano
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default PlansPage;
