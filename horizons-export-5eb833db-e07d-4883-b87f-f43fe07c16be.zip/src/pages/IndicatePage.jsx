
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";
import { User, Phone, Hash, DollarSign, MapPin, UserPlus, Home, Send } from "lucide-react";

const IndicatePage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const whatsappNumber = "91999887733";

  const [formData, setFormData] = useState({
    referrerName: "",
    referrerPhone: "",
    referrerCpf: "",
    referrerPix: "",
    referrerCity: "",
    referredName: "",
    referredPhone: "",
    referredNeighborhood: "",
    referredCity: "",
  });

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData((prevData) => ({ ...prevData, [id]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const {
      referrerName, referrerPhone, referrerCpf, referrerPix, referrerCity,
      referredName, referredPhone, referredNeighborhood, referredCity: referredCityValue
    } = formData;

    if (!referrerName || !referrerPhone || !referrerCpf || !referrerPix || !referrerCity ||
        !referredName || !referredPhone || !referredNeighborhood || !referredCityValue) {
      toast({
        title: "Campos obrigatórios",
        description: "Por favor, preencha todos os campos do formulário.",
        variant: "destructive",
      });
      return;
    }
    
    const message = `Olá! Gostaria de fazer uma indicação:
    
*Meus Dados:*
Nome: ${referrerName}
Telefone: ${referrerPhone}
CPF: ${referrerCpf}
Chave PIX: ${referrerPix}
Minha Cidade: ${referrerCity}

*Dados do Indicado:*
Nome: ${referredName}
Telefone: ${referredPhone}
Bairro: ${referredNeighborhood}
Cidade do Indicado: ${referredCityValue}
    
Obrigado!`;

    const whatsappUrl = `https://api.whatsapp.com/send?phone=${whatsappNumber}&text=${encodeURIComponent(message)}`;
    
    toast({
      title: "Indicação quase lá!",
      description: "Você será redirecionado para o WhatsApp para enviar sua indicação.",
    });

    setTimeout(() => {
      window.open(whatsappUrl, "_blank");
      navigate("/");
    }, 2000);
  };

  const inputFields = [
    { id: "referrerName", label: "Seu Nome Completo", placeholder: "Seu nome completo", icon: <User className="h-4 w-4 text-muted-foreground" /> },
    { id: "referrerPhone", label: "Seu Telefone (com DDD)", placeholder: "Ex: 91999998888", type: "tel", icon: <Phone className="h-4 w-4 text-muted-foreground" /> },
    { id: "referrerCpf", label: "Seu CPF (somente números)", placeholder: "Seu CPF", icon: <Hash className="h-4 w-4 text-muted-foreground" /> },
    { id: "referrerPix", label: "Sua Chave PIX", placeholder: "Sua chave Pix", icon: <DollarSign className="h-4 w-4 text-muted-foreground" /> },
    { id: "referrerCity", label: "Sua Cidade", placeholder: "Cidade onde você mora", icon: <MapPin className="h-4 w-4 text-muted-foreground" /> },
  ];

  const referredInputFields = [
    { id: "referredName", label: "Nome Completo do Indicado", placeholder: "Nome completo do seu amigo", icon: <UserPlus className="h-4 w-4 text-muted-foreground" /> },
    { id: "referredPhone", label: "Telefone do Indicado (com DDD)", placeholder: "Ex: 91988887777", type: "tel", icon: <Phone className="h-4 w-4 text-muted-foreground" /> },
    { id: "referredNeighborhood", label: "Bairro do Indicado", placeholder: "Bairro do seu amigo", icon: <Home className="h-4 w-4 text-muted-foreground" /> },
    { id: "referredCity", label: "Cidade do Indicado", placeholder: "Cidade do seu amigo", icon: <MapPin className="h-4 w-4 text-muted-foreground" /> },
  ];

  return (
    <div className="container mx-auto max-w-2xl px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="shadow-xl">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
              <UserPlus size={32} className="text-green-500" />
            </div>
            <CardTitle className="text-3xl font-bold text-green-600">Formulário de Indicação</CardTitle>
            <CardDescription className="text-md">
              Preencha os dados abaixo para realizar sua indicação.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-8">
              <div>
                <h3 className="mb-4 text-xl font-semibold text-gray-700">Seus Dados</h3>
                <div className="space-y-4">
                  {inputFields.map((field) => (
                    <div key={field.id} className="space-y-2">
                      <Label htmlFor={field.id} className="flex items-center gap-2 text-gray-700">
                        {field.icon}
                        {field.label}
                      </Label>
                      <Input
                        id={field.id}
                        placeholder={field.placeholder}
                        type={field.type || "text"}
                        value={formData[field.id]}
                        onChange={handleChange}
                        className="border-gray-300 focus:border-green-500 focus:ring-green-500"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="mb-4 text-xl font-semibold text-gray-700">Dados do Indicado</h3>
                <div className="space-y-4">
                  {referredInputFields.map((field) => (
                    <div key={field.id} className="space-y-2">
                      <Label htmlFor={field.id} className="flex items-center gap-2 text-gray-700">
                        {field.icon}
                        {field.label}
                      </Label>
                      <Input
                        id={field.id}
                        placeholder={field.placeholder}
                        type={field.type || "text"}
                        value={formData[field.id]}
                        onChange={handleChange}
                        className="border-gray-300 focus:border-green-500 focus:ring-green-500"
                      />
                    </div>
                  ))}
                </div>
              </div>
              
              <Button type="submit" size="lg" className="w-full bg-green-500 text-lg font-semibold text-white hover:bg-green-600">
                <Send size={20} className="mr-2" />
                Enviar Indicação
              </Button>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default IndicatePage;
