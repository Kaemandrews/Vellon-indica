import React, { createContext, useState, useContext, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [adminHasNewIndications, setAdminHasNewIndications] = useState(false);
  const [userHasNewComunicados, setUserHasNewComunicados] = useState(false);
  const [latestComunicado, setLatestComunicado] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    const storedUserSession = localStorage.getItem('vellonIndica_userSession');
    if (storedUserSession) {
      try {
        const parsedUser = JSON.parse(storedUserSession);
        setUser(parsedUser);
        if (parsedUser?.isAdmin) {
          checkAdminNotifications();
        } else {
          checkUserComunicados(parsedUser?.id);
        }
      } catch (error) {
        console.error('Failed to parse stored user session:', error);
        localStorage.removeItem('vellonIndica_userSession');
      }
    }
    fetchLatestComunicado();
    setLoading(false);
  }, []);

  const fetchLatestComunicado = () => {
    const comunicados = JSON.parse(localStorage.getItem('vellonIndica_comunicados')) || [];
    if (comunicados.length > 0) {
      setLatestComunicado(comunicados[0]); // Pega o mais recente (primeiro da lista)
    } else {
      setLatestComunicado(null);
    }
  };


  const checkAdminNotifications = () => {
    const newIndicationFlag = localStorage.getItem('vellonIndica_newIndicationForAdmin');
    const indications = JSON.parse(localStorage.getItem('vellonIndica_indicacoes')) || [];
    const lastChecked = localStorage.getItem('vellonIndica_adminLastCheckedIndications');

    if (newIndicationFlag === 'true') {
      setAdminHasNewIndications(true);
    } else if (lastChecked) {
      const newIndicationsSinceLastCheck = indications.filter(ind => new Date(ind.data) > new Date(lastChecked));
      if (newIndicationsSinceLastCheck.length > 0) {
        setAdminHasNewIndications(true);
      }
    } else if (!lastChecked && indications.length > 0) {
      setAdminHasNewIndications(true);
    }
  };

  const clearAdminIndicationsNotification = () => {
    setAdminHasNewIndications(false);
    localStorage.removeItem('vellonIndica_newIndicationForAdmin');
    localStorage.setItem('vellonIndica_adminLastCheckedIndications', new Date().toISOString());
  };
  
  const checkUserComunicados = (userId) => {
    if (!userId) return;
    const comunicados = JSON.parse(localStorage.getItem('vellonIndica_comunicados')) || [];
    const userReadComunicadosKey = `vellonIndica_readComunicados_${userId}`;
    const readComunicados = JSON.parse(localStorage.getItem(userReadComunicadosKey)) || [];
    const unreadCount = comunicados.filter(c => !readComunicados.includes(c.id)).length;
    setUserHasNewComunicados(unreadCount > 0);
  };

  const clearUserComunicadosNotification = (userId) => {
     if (!userId) return;
    setUserHasNewComunicados(false);
  };


  const login = (email, password) => {
    setLoading(true);
    fetchLatestComunicado(); // Atualiza o comunicado no login
    // Admin User Check
    if (email === 'admin@vellon.com' && password === 'VellonAdmin@2025') {
      const adminData = { id: 'admin', name: 'Administrador', email, isAdmin: true };
      setUser(adminData);
      localStorage.setItem('vellonIndica_userSession', JSON.stringify(adminData));
      checkAdminNotifications();
      setLoading(false);
      toast({
        title: "Login de Administrador bem-sucedido!",
        description: `Bem-vindo, Administrador!`,
      });
      return true;
    }

    const storedUsers = JSON.parse(localStorage.getItem('vellonIndica_users')) || [];
    const foundUser = storedUsers.find(u => u.email === email && u.password === password);

    if (foundUser) {
      const userData = { id: foundUser.email, name: foundUser.name, email: foundUser.email, isAdmin: false };
      setUser(userData);
      localStorage.setItem('vellonIndica_userSession', JSON.stringify(userData));
      checkUserComunicados(userData.id);
      setLoading(false);
      toast({
        title: "Login bem-sucedido!",
        description: `Bem-vindo, ${userData.name}!`,
      });
      return true;
    }
    
    if (email === 'user@example.com' && password === 'password') {
      const userData = { id: '1', name: 'Usuário Teste Padrão', email, isAdmin: false };
      setUser(userData);
      localStorage.setItem('vellonIndica_userSession', JSON.stringify(userData));
      checkUserComunicados(userData.id);
      setLoading(false);
      toast({
        title: "Login bem-sucedido!",
        description: `Bem-vindo, ${userData.name}! (Usuário Padrão)`,
      });
      return true;
    }
    setLoading(false);
    toast({
      variant: "destructive",
      title: "Falha no login",
      description: "Email ou senha inválidos.",
    });
    return false;
  };

  const logout = () => {
    setUser(null);
    setAdminHasNewIndications(false);
    setUserHasNewComunicados(false);
    setLatestComunicado(null);
    localStorage.removeItem('vellonIndica_userSession');
    toast({
      title: "Logout realizado",
      description: "Você saiu da sua conta.",
    });
  };

  const value = {
    user,
    loading,
    login,
    logout,
    isAuthenticated: !!user,
    adminHasNewIndications,
    clearAdminIndicationsNotification,
    userHasNewComunicados,
    clearUserComunicadosNotification,
    checkUserComunicados,
    latestComunicado,
    fetchLatestComunicado, // Expor para atualizar o letreiro quando um novo comunicado é enviado
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === null) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};