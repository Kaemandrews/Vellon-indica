import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';

function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  React.useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    const success = login(email, password);
    
    if (success) {
      navigate('/dashboard');
    }
    setIsLoading(false);
  };

  return (
    <div className="min-h-[calc(100vh-150px)] flex flex-col items-center justify-center login-bg px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: -30, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, type: "spring", stiffness: 100, damping: 15 }}
        className="w-full max-w-md"
      >
        <div className="login-card p-8 md:p-10 space-y-8">
          <div className="text-center space-y-2">
            <h1 className="login-title">Login</h1>
            <p className="text-muted-foreground text-sm md:text-base">
              Acesse sua conta para utilizar o sistema de indicações.
            </p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium text-gray-700">E-mail</Label>
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="bg-white border-gray-300 focus:border-primary focus:ring-primary rounded-lg text-sm"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium text-gray-700">Senha</Label>
              <Input
                id="password"
                type="password"
                placeholder="Sua senha"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="bg-white border-gray-300 focus:border-primary focus:ring-primary rounded-lg text-sm"
              />
            </div>
            
            <Button
              type="submit"
              className="w-full login-button text-base"
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Entrando...
                </div>
              ) : (
                <div className="flex items-center justify-center">
                  <LogIn className="mr-2 h-4 w-4 md:h-5 md:w-5" />
                  Entrar
                </div>
              )}
            </Button>
          </form>

          <div className="text-center space-y-2 text-sm">
            <p>
              Não possui uma conta?{' '}
              <Link to="/register" className="link-primary font-medium">
                Cadastre-se
              </Link>
            </p>
            <p>
              <Link to="/forgot-password" className="link-primary font-medium">
                Esqueci minha senha
              </Link>
            </p>
          </div>
        </div>
      </motion.div>
      <footer className="text-center mt-12 text-sm text-gray-600">
        <p>&copy; {new Date().getFullYear()} Vellon Telecom. Todos os direitos reservados.</p>
        <p className="mt-1">Entre em contato via <Link to="#" className="link-primary">suporte</Link></p>
      </footer>
    </div>
  );
}

export default LoginPage;