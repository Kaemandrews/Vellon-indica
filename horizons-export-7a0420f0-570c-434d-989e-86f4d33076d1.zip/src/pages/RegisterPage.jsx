import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { UserPlus, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from "@/components/ui/use-toast";

function RegisterPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  React.useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    if (password !== confirmPassword) {
      toast({
        variant: "destructive",
        title: "Erro de Cadastro",
        description: "As senhas não coincidem.",
      });
      setIsLoading(false);
      return;
    }

    if (password.length < 6) {
      toast({
        variant: "destructive",
        title: "Erro de Cadastro",
        description: "A senha deve ter pelo menos 6 caracteres.",
      });
      setIsLoading(false);
      return;
    }
    
    console.log("Tentativa de registro:", { name, email, password });
    
    setTimeout(() => {
      const users = JSON.parse(localStorage.getItem('vellonIndica_users')) || [];
      const existingUser = users.find(u => u.email === email);

      if (existingUser) {
        toast({
          variant: "destructive",
          title: "Erro de Cadastro",
          description: "Este email já está cadastrado.",
        });
        setIsLoading(false);
        return;
      }

      users.push({ name, email, password }); // Armazenando a senha (apenas para simulação)
      localStorage.setItem('vellonIndica_users', JSON.stringify(users));
      
      toast({
        title: "Cadastro realizado com sucesso!",
        description: "Agora você pode fazer login com suas credenciais.",
      });
      navigate('/login');
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-[calc(100vh-150px)] flex flex-col items-center justify-center login-bg px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: -30, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, type: "spring", stiffness: 100, damping: 15 }}
        className="w-full max-w-md"
      >
        <div className="login-card p-8 md:p-10 space-y-8">
          <div className="text-center space-y-2">
            <h1 className="login-title">Criar Conta</h1>
            <p className="text-muted-foreground text-sm md:text-base">
              Junte-se ao Vellon Indica e comece a ganhar!
            </p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-1.5">
              <Label htmlFor="name" className="text-sm font-medium text-gray-700">Nome Completo</Label>
              <Input
                id="name"
                type="text"
                placeholder="Seu nome completo"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                className="bg-white border-gray-300 focus:border-primary focus:ring-primary rounded-lg text-sm"
              />
            </div>
             <div className="space-y-1.5">
              <Label htmlFor="email" className="text-sm font-medium text-gray-700">E-mail</Label>
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="bg-white border-gray-300 focus:border-primary focus:ring-primary rounded-lg text-sm"
              />
            </div>
            
            <div className="space-y-1.5">
              <Label htmlFor="password" className="text-sm font-medium text-gray-700">Senha</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  placeholder="Crie uma senha forte (mín. 6 caracteres)"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="bg-white border-gray-300 focus:border-primary focus:ring-primary rounded-lg text-sm"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-primary"
                  aria-label={showPassword ? "Esconder senha" : "Mostrar senha"}
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="confirmPassword" className="text-sm font-medium text-gray-700">Confirmar Senha</Label>
              <Input
                id="confirmPassword"
                type={showPassword ? "text" : "password"}
                placeholder="Repita sua senha"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                className="bg-white border-gray-300 focus:border-primary focus:ring-primary rounded-lg text-sm"
              />
            </div>
            
            <Button
              type="submit"
              className="w-full login-button text-base"
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Criando conta...
                </div>
              ) : (
                <div className="flex items-center justify-center">
                  <UserPlus className="mr-2 h-4 w-4 md:h-5 md:w-5" />
                  Cadastrar
                </div>
              )}
            </Button>
          </form>

          <div className="text-center space-y-2 text-sm">
            <p>
              Já possui uma conta?{' '}
              <Link to="/login" className="link-primary font-medium">
                Faça Login
              </Link>
            </p>
          </div>
        </div>
      </motion.div>
       <footer className="text-center mt-12 text-sm text-gray-600">
        <p>&copy; {new Date().getFullYear()} Vellon Telecom. Todos os direitos reservados.</p>
      </footer>
    </div>
  );
}

export default RegisterPage;