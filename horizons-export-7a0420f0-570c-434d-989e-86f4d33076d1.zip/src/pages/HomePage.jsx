import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, Gift, Users, TrendingUp, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';

function HomePage() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  const featureCards = [
    {
      icon: <Gift className="h-8 w-8 text-primary" />,
      title: "Indique e Ganhe",
      description: "Compartilhe seu link exclusivo e seja recompensado por cada novo cliente.",
    },
    {
      icon: <Users className="h-8 w-8 text-primary" />,
      title: "Fácil de Participar",
      description: "Cadastro simples e rápido para começar a indicar em minutos.",
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-primary" />,
      title: "Acompanhe Seus Resultados",
      description: "Painel intuitivo para visualizar suas indicações e ganhos.",
    },
  ];

  return (
    <div className="space-y-16 my-8">
      <section className="text-center py-12 md:py-20 relative overflow-hidden rounded-xl bg-gradient-to-br from-primary/80 via-primary/70 to-secondary/70 text-primary-foreground shadow-xl">
        <div className="absolute inset-0 bg-white/10 backdrop-blur-sm"></div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="relative z-10"
        >
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 drop-shadow-md">
            Bem-vindo ao <span className="text-yellow-300">Vellon Indica</span>!
          </h1>
          <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto text-primary-foreground/95 drop-shadow-sm">
            Indique nossos serviços para seus amigos e ganhe recompensas incríveis. Quanto mais você indica, mais você ganha!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              onClick={() => navigate(isAuthenticated ? '/dashboard' : '/login')}
              className="bg-primary-foreground text-primary hover:bg-primary-foreground/90 shadow-lg text-lg px-8 py-3"
            >
              {isAuthenticated ? 'Meu Painel' : 'Começar a Indicar'}
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
            {!isAuthenticated && (
                <Button 
                variant="outline" 
                size="lg" 
                onClick={() => navigate('/register')}
                className="border-primary-foreground/80 text-primary-foreground hover:bg-primary-foreground/10 shadow-lg text-lg px-8 py-3"
              >
                Criar Conta
              </Button>
            )}
          </div>
        </motion.div>
      </section>

      <section>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Por que participar do <span className="text-primary">Vellon Indica</span>?
          </h2>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto">
            Descubra as vantagens de fazer parte do nosso programa de indicações.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {featureCards.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card className="h-full hover:shadow-primary/20 hover:shadow-xl transition-all duration-300 border-border rounded-xl overflow-hidden">
                <CardHeader className="bg-primary/5 p-6">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4 ring-4 ring-primary/20">
                    {feature.icon}
                  </div>
                  <CardTitle className="text-xl text-primary">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <p className="text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="text-center py-12 md:py-16 bg-slate-50 rounded-xl shadow-xl border border-border">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <ShieldCheck className="h-16 w-16 text-primary mx-auto mb-6" />
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Segurança e Transparência <span className="text-primary">Garantidas</span>
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto">
            Nosso sistema é seguro e todas as suas indicações são rastreadas de forma transparente. Conte com a Vellon para uma parceria de sucesso!
          </p>
          <Button 
            size="lg" 
            onClick={() => navigate('/login')}
            className="shadow-lg bg-primary text-primary-foreground hover:bg-primary/90 text-lg px-8 py-3"
          >
            Junte-se Agora
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </motion.div>
      </section>
    </div>
  );
}

export default HomePage;