import React from 'react';
import { Outlet, NavLink } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, 
  HeartHandshake as Handshake, 
  UserCircle, 
  LogOut, 
  UserPlus,
  ShieldCheck,
  Gavel,
  MapPin,
  Building,
  Megaphone,
  Bell,
  ScrollText,
  Users2,
  Info,
  Wifi
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

function DashboardPage() {
  const { user, logout } = useAuth();

  const commonLinks = [
    { name: 'Visão Geral', path: '/dashboard', icon: LayoutDashboard, exact: true },
    { name: 'Minhas Indicações', path: '/dashboard/indicacoes', icon: Handshake },
    { name: 'Indicar Amigo', path: '/dashboard/indicar-amigo', icon: UserPlus },
    { name: 'Nossos Planos', path: '/dashboard/planos', icon: Wifi },
    { name: 'Comunicados', path: '/dashboard/comunicados', icon: Bell },
    { name: 'Regras da Promoção', path: '/dashboard/regras', icon: ScrollText },
    { name: 'Cidades Participantes', path: '/dashboard/cidades-participantes', icon: MapPin },
    { name: 'Empresas Parceiras', path: '/dashboard/empresas-parceiras', icon: Users2 },
  ];

  const adminLinks = [
    { name: 'Gerenciar Regras', path: '/dashboard/admin/regras', icon: Gavel },
    { name: 'Gerenciar Cidades', path: '/dashboard/admin/cidades', icon: Info },
    { name: 'Gerenciar Parceiros', path: '/dashboard/admin/parceiros', icon: Building },
    { name: 'Enviar Comunicado', path: '/dashboard/admin/comunicados', icon: Megaphone },
  ];

  const sidebarLinks = user?.isAdmin ? [...commonLinks, ...adminLinks] : commonLinks;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col md:flex-row gap-6 md:gap-8 min-h-[calc(100vh-200px)]"
    >
      <motion.aside 
        initial={{ x: -50, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.4, delay: 0.1 }}
        className="md:w-64 lg:w-72 flex-shrink-0"
      >
        <Card className="shadow-lg border-border h-full rounded-xl">
          <CardContent className="p-4 md:p-6 h-full flex flex-col">
            <div className="mb-8">
              <div className="flex items-center space-x-3 p-3 rounded-lg bg-primary/10">
                <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-primary-foreground text-xl font-semibold">
                  {user?.isAdmin ? <ShieldCheck size={24} /> : (user?.name ? user.name.charAt(0).toUpperCase() : <UserCircle size={24} />)}
                </div>
                <div>
                  <p className="font-semibold text-primary truncate">{user?.name || 'Usuário'}</p>
                  <p className="text-xs text-muted-foreground truncate">{user?.email || 'email@example.com'}</p>
                </div>
              </div>
            </div>

            <nav className="flex-grow space-y-1.5">
              {sidebarLinks.map((link) => (
                <NavLink
                  key={link.name}
                  to={link.path}
                  end={link.exact}
                  className={({ isActive }) =>
                    `flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-all duration-200 ease-in-out
                    ${isActive ? 'bg-primary text-primary-foreground shadow-md scale-105' : 'hover:bg-primary/10 hover:text-primary focus:bg-primary/10 focus:text-primary'}`
                  }
                >
                  <link.icon className="h-5 w-5 flex-shrink-0" />
                  <span className="font-medium text-sm">{link.name}</span>
                </NavLink>
              ))}
            </nav>

            <div className="mt-auto pt-6">
              <Button onClick={logout} variant="outline" className="w-full border-primary text-primary hover:bg-primary/10">
                <LogOut className="mr-2 h-4 w-4" />
                Sair
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.aside>

      <motion.main 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
        className="flex-1 overflow-auto"
      >
        <Outlet />
      </motion.main>
    </motion.div>
  );
}

export default DashboardPage;