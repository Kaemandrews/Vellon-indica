import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { MapPin } from 'lucide-react';

function UserCidadesPage() {
  const [cities, setCities] = useState([]);

  useEffect(() => {
    const storedCities = localStorage.getItem('vellonIndica_cities');
    if (storedCities) {
      setCities(JSON.parse(storedCities));
    }
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      <motion.div variants={itemVariants} className="flex items-center gap-3">
        <MapPin className="h-10 w-10 text-primary" />
        <div>
          <h1 className="text-3xl md:text-4xl font-bold">Cidades Participantes</h1>
          <p className="text-muted-foreground mt-1 text-lg">Veja onde a promoção "Vellon Indica" está ativa.</p>
        </div>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="shadow-xl rounded-xl border-border">
          <CardHeader className="bg-slate-50/50 border-b p-4 md:p-6">
            <CardTitle className="text-xl text-primary">Localidades Ativas</CardTitle>
            <CardDescription>A promoção é válida nas seguintes cidades:</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            {cities.length > 0 ? (
              <ul className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                {cities.map((city) => (
                  <motion.li 
                    key={city.id} 
                    variants={itemVariants}
                    className="flex items-center gap-2 p-3 border rounded-lg bg-background hover:bg-slate-50/50 transition-colors"
                  >
                    <MapPin size={20} className="text-primary flex-shrink-0" />
                    <span className="text-md font-medium text-gray-700">{city.name}</span>
                  </motion.li>
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground text-center py-6">Nenhuma cidade participante cadastrada no momento.</p>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}

export default UserCidadesPage;