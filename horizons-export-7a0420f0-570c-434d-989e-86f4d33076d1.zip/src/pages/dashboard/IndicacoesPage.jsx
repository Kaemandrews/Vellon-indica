import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { HeartHandshake as Handshake, Users, TrendingUp, Search, FileDown, Edit3, Phone, KeyRound } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from "@/components/ui/use-toast";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog.jsx";
import { getStatusBadge, containerVariants, itemVariants } from '@/lib/page_utils';


const StatCard = ({ title, value, icon: Icon, color, bgColor, hasNotification }) => (
  <motion.div variants={itemVariants} className="relative">
    {hasNotification && (
      <div className="absolute top-2 right-2 w-3 h-3 bg-red-500 rounded-full z-10 animate-pulse"></div>
    )}
    <Card className={`shadow-lg hover:shadow-xl transition-all duration-300 border-transparent rounded-xl overflow-hidden ${bgColor}`}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 pt-6 px-6">
        <CardTitle className={`text-sm font-medium ${color}`}>{title}</CardTitle>
        <Icon className={`h-6 w-6 ${color}`} />
      </CardHeader>
      <CardContent className="px-6 pb-6">
        <div className={`text-4xl font-bold ${color}`}>{value}</div>
      </CardContent>
    </Card>
  </motion.div>
);

const IndicationRow = ({ referral, isAdmin, onEdit }) => (
  <TableRow className="hover:bg-slate-50/30 transition-colors text-sm">
    {isAdmin && (
      <>
        <TableCell className="font-medium px-4 py-3 whitespace-nowrap">{referral.indicadorNome}</TableCell>
        <TableCell className="px-4 py-3 whitespace-nowrap">{referral.indicadorTelefone}</TableCell>
        <TableCell className="px-4 py-3 whitespace-nowrap">{referral.indicadorChavePix}</TableCell>
      </>
    )}
    <TableCell className="font-medium px-4 py-3 whitespace-nowrap">{referral.indicadoNome}</TableCell>
    <TableCell className="px-4 py-3 whitespace-nowrap">{referral.indicadoTelefone}</TableCell>
    <TableCell className="px-4 py-3 whitespace-nowrap">{getStatusBadge(referral.status)}</TableCell>
    <TableCell className="px-4 py-3 whitespace-nowrap">{new Date(referral.data).toLocaleDateString('pt-BR')}</TableCell>
    {isAdmin && (
      <TableCell className="px-4 py-3 whitespace-nowrap text-right">
        <Button variant="ghost" size="sm" onClick={() => onEdit(referral)} className="text-primary hover:text-primary/80">
          <Edit3 size={16} />
        </Button>
      </TableCell>
    )}
  </TableRow>
);

const EditStatusModal = ({ indication, isOpen, onOpenChange, onSave, currentStatus, onStatusChange }) => {
  if (!indication) return null;
  return (
    <AlertDialog open={isOpen} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Editar Status da Indicação</AlertDialogTitle>
          <AlertDialogDescription>
            Alterar o status para: <span className="font-semibold">{indication.indicadoNome}</span>
          </AlertDialogDescription>
        </AlertDialogHeader>
        <div className="my-4">
          <Label htmlFor="status-select-modal">Novo Status</Label>
          <Select value={currentStatus} onValueChange={onStatusChange}>
            <SelectTrigger id="status-select-modal" className="w-full mt-1">
              <SelectValue placeholder="Selecione um status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Pendente">Pendente</SelectItem>
              <SelectItem value="Em Negociação">Em Negociação</SelectItem>
              <SelectItem value="Convertida">Convertida</SelectItem>
              <SelectItem value="Não Convertida">Não Convertida</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={() => onOpenChange(false)}>Cancelar</AlertDialogCancel>
          <AlertDialogAction onClick={onSave} disabled={!currentStatus || currentStatus === indication.status}>
            Salvar Alterações
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};


function IndicacoesPage() {
  const { user, adminHasNewIndications, clearAdminIndicationsNotification } = useAuth();
  const { toast } = useToast();
  const [allIndications, setAllIndications] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [editingIndication, setEditingIndication] = useState(null);
  const [newStatusModal, setNewStatusModal] = useState('');

  useEffect(() => {
    const loadedIndications = JSON.parse(localStorage.getItem('vellonIndica_indicacoes')) || [];
    if (user?.isAdmin) {
      setAllIndications(loadedIndications.sort((a,b) => new Date(b.data) - new Date(a.data)));
      if (user?.isAdmin && adminHasNewIndications) {
        clearAdminIndicationsNotification();
      }
    } else {
      setAllIndications(loadedIndications.filter(ind => ind.indicadorEmail === user?.email).sort((a,b) => new Date(b.data) - new Date(a.data)));
    }
  }, [user, adminHasNewIndications, clearAdminIndicationsNotification]);

  const handleSaveStatusChange = () => {
    if (!editingIndication || !newStatusModal) return;

    const allIndicationsForStorage = JSON.parse(localStorage.getItem('vellonIndica_indicacoes')) || [];
    const globallyUpdatedIndications = allIndicationsForStorage
        .map(ind => ind.id === editingIndication.id ? { ...ind, status: newStatusModal } : ind)
        .sort((a,b) => new Date(b.data) - new Date(a.data));
    
    localStorage.setItem('vellonIndica_indicacoes', JSON.stringify(globallyUpdatedIndications));
    
    if (user?.isAdmin) {
        setAllIndications(globallyUpdatedIndications);
    } else {
        setAllIndications(globallyUpdatedIndications.filter(ind => ind.indicadorEmail === user?.email));
    }

    toast({ title: "Status Atualizado", description: `Status da indicação alterado para ${newStatusModal}.` });
    setEditingIndication(null);
    setNewStatusModal('');
  };

  const openEditModal = (indication) => {
    setEditingIndication(indication);
    setNewStatusModal(indication.status);
  };

  const stats = useMemo(() => {
    const relevantIndications = user?.isAdmin 
      ? allIndications 
      : allIndications.filter(ind => ind.indicadorEmail === user?.email);

    const total = relevantIndications.length;
    const emNegociacao = relevantIndications.filter(r => r.status === 'Em Negociação').length;
    const convertidas = relevantIndications.filter(r => r.status === 'Convertida').length;
    return { total, emNegociacao, convertidas };
  }, [allIndications, user]);

  const filteredReferrals = useMemo(() => {
    return allIndications.filter(referral => {
      const searchLower = searchTerm.toLowerCase();
      const matchesSearchTerm = 
        (referral.indicadoNome?.toLowerCase() || '').includes(searchLower) ||
        (referral.indicadoTelefone || '').includes(searchTerm) ||
        (user?.isAdmin && (
          (referral.indicadorNome?.toLowerCase() || '').includes(searchLower) ||
          (referral.indicadorTelefone || '').includes(searchTerm) ||
          (referral.indicadorChavePix?.toLowerCase() || '').includes(searchLower)
        ));
      const matchesStatus = statusFilter === 'all' || referral.status === statusFilter;
      return matchesSearchTerm && matchesStatus;
    });
  }, [searchTerm, statusFilter, allIndications, user]);

  const statCardsData = [
    { title: "Indicações Feitas", value: stats.total, icon: Users, color: "text-blue-500", bgColor: "bg-blue-50", hasNotification: user?.isAdmin && adminHasNewIndications },
    { title: "Em Negociação", value: stats.emNegociacao, icon: Handshake, color: "text-yellow-500", bgColor: "bg-yellow-50" },
    { title: "Negociações Fechadas", value: stats.convertidas, icon: TrendingUp, color: "text-green-500", bgColor: "bg-green-50" },
  ];

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      <motion.div variants={itemVariants}>
        <h1 className="text-3xl md:text-4xl font-bold">Minhas Indicações</h1>
        <p className="text-muted-foreground mt-1 text-lg">Acompanhe o status de todas as suas indicações.</p>
      </motion.div>

      <motion.div 
        variants={containerVariants}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {statCardsData.map((card) => (
          <StatCard key={card.title} {...card} />
        ))}
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="shadow-xl rounded-xl border-border overflow-hidden">
          <CardHeader className="bg-slate-50/50 border-b p-4 md:p-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <CardTitle className="text-xl text-primary">Lista de Indicações</CardTitle>
              <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
                 <div className="relative w-full sm:w-auto md:min-w-[250px]">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder={user?.isAdmin ? "Buscar por indicado, telefone, indicador, pix..." : "Buscar por nome do indicado, telefone..."}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 text-sm rounded-lg"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-full sm:w-[180px] text-sm rounded-lg">
                    <SelectValue placeholder="Filtrar por status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos Status</SelectItem>
                    <SelectItem value="Pendente">Pendente</SelectItem>
                    <SelectItem value="Em Negociação">Em Negociação</SelectItem>
                    <SelectItem value="Convertida">Convertida</SelectItem>
                    <SelectItem value="Não Convertida">Não Convertida</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" className="text-sm rounded-lg w-full sm:w-auto border-primary text-primary hover:bg-primary/10">
                  <FileDown size={16} className="mr-2"/> Exportar
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="bg-slate-50">
                    {user?.isAdmin && (
                      <>
                        <TableHead className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Indicador</TableHead>
                        <TableHead className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Telefone Indicador</TableHead>
                        <TableHead className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Pix Indicador</TableHead>
                      </>
                    )}
                    <TableHead className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Nome Indicado</TableHead>
                    <TableHead className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Telefone Indicado</TableHead>
                    <TableHead className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Status</TableHead>
                    <TableHead className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">Data</TableHead>
                    {user?.isAdmin && <TableHead className="px-4 py-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground text-right">Ações</TableHead>}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReferrals.length > 0 ? (
                    filteredReferrals.map((referral) => (
                      <IndicationRow 
                        key={referral.id} 
                        referral={referral} 
                        isAdmin={user?.isAdmin} 
                        onEdit={openEditModal}
                      />
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={user?.isAdmin ? 8 : 5} className="h-24 text-center text-muted-foreground">
                        Nenhuma indicação encontrada com os filtros atuais.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <EditStatusModal 
        indication={editingIndication}
        isOpen={!!editingIndication}
        onOpenChange={(isOpen) => {
          if (!isOpen) {
            setEditingIndication(null);
            setNewStatusModal('');
          }
        }}
        onSave={handleSaveStatusChange}
        currentStatus={newStatusModal}
        onStatusChange={setNewStatusModal}
      />
    </motion.div>
  );
}

export default IndicacoesPage;