import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useToast } from "@/components/ui/use-toast";
import { UserPlus, Send } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

function IndicarAmigoPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    indicadorNome: '',
    indicadorTelefone: '',
    indicadorChavePix: '',
    indicadoNome: '',
    indicadoTelefone: '',
    indicadoBairro: '',
    indicadoCidade: '',
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (user) {
      setFormData(prev => ({
        ...prev,
        indicadorNome: user.name || '',
        // Recuperar telefone e chave pix se já foram informados antes e salvos
        indicadorTelefone: localStorage.getItem(`indicadorTelefone_${user.id}`) || '',
        indicadorChavePix: localStorage.getItem(`indicadorChavePix_${user.id}`) || '',
      }));
    }
  }, [user]);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);

    if (user) {
        localStorage.setItem(`indicadorTelefone_${user.id}`, formData.indicadorTelefone);
        localStorage.setItem(`indicadorChavePix_${user.id}`, formData.indicadorChavePix);
    }

    const newIndication = {
      id: Date.now(), 
      indicadorEmail: user?.email,
      indicadorNome: formData.indicadorNome,
      indicadorTelefone: formData.indicadorTelefone,
      indicadorChavePix: formData.indicadorChavePix,
      indicadoNome: formData.indicadoNome,
      indicadoTelefone: formData.indicadoTelefone,
      indicadoBairro: formData.indicadoBairro,
      indicadoCidade: formData.indicadoCidade,
      data: new Date().toISOString(), 
      status: 'Pendente', 
    };

    setTimeout(() => {
      try {
        const existingIndications = JSON.parse(localStorage.getItem('vellonIndica_indicacoes')) || [];
        existingIndications.unshift(newIndication); 
        localStorage.setItem('vellonIndica_indicacoes', JSON.stringify(existingIndications));
        
        localStorage.setItem('vellonIndica_newIndicationForAdmin', 'true');

        toast({
          title: "Indicação Enviada!",
          description: "Sua indicação foi registrada com sucesso.",
        });
        // Limpar apenas os dados do indicado
        setFormData(prev => ({
          ...prev,
          indicadoNome: '',
          indicadoTelefone: '',
          indicadoBairro: '',
          indicadoCidade: '',
        }));
      } catch (error) {
        console.error("Erro ao salvar indicação:", error);
        toast({
          variant: "destructive",
          title: "Erro ao Enviar",
          description: "Não foi possível registrar sua indicação. Tente novamente.",
        });
      } finally {
        setIsLoading(false);
      }
    }, 1500);
  };
  
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      <motion.div variants={itemVariants}>
        <div className="flex items-center gap-3">
          <UserPlus className="h-10 w-10 text-primary" />
          <div>
            <h1 className="text-3xl md:text-4xl font-bold">Indicar um Amigo</h1>
            <p className="text-muted-foreground mt-1 text-lg">Preencha os dados abaixo para realizar sua indicação.</p>
          </div>
        </div>
      </motion.div>

      <motion.form onSubmit={handleSubmit} variants={itemVariants}>
        <Card className="shadow-xl rounded-xl border-border overflow-hidden">
          <CardHeader className="bg-slate-50/50 border-b p-4 md:p-6">
            <CardTitle className="text-xl text-primary">Seus Dados</CardTitle>
            <CardDescription>Informações sobre você, o indicador.</CardDescription>
          </CardHeader>
          <CardContent className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <Label htmlFor="indicadorNome">Nome Completo</Label>
              <Input id="indicadorNome" placeholder="Seu nome completo" value={formData.indicadorNome} onChange={handleChange} required disabled={!!user?.name} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="indicadorTelefone">Telefone (com DDD)</Label>
              <Input id="indicadorTelefone" type="tel" placeholder="Ex: (99) 99999-9999" value={formData.indicadorTelefone} onChange={handleChange} required />
            </div>
            <div className="space-y-1.5 md:col-span-2">
              <Label htmlFor="indicadorChavePix">Chave Pix</Label>
              <Input id="indicadorChavePix" placeholder="Sua chave Pix para receber o prêmio" value={formData.indicadorChavePix} onChange={handleChange} required />
            </div>
          </CardContent>
        </Card>

        <Card className="shadow-xl rounded-xl border-border overflow-hidden mt-8">
          <CardHeader className="bg-slate-50/50 border-b p-4 md:p-6">
            <CardTitle className="text-xl text-primary">Dados do Indicado</CardTitle>
            <CardDescription>Informações sobre a pessoa que você está indicando.</CardDescription>
          </CardHeader>
          <CardContent className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5">
              <Label htmlFor="indicadoNome">Nome Completo do Indicado</Label>
              <Input id="indicadoNome" placeholder="Nome completo do seu amigo" value={formData.indicadoNome} onChange={handleChange} required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="indicadoTelefone">Telefone do Indicado (com DDD)</Label>
              <Input id="indicadoTelefone" type="tel" placeholder="Ex: (91) 98888-7777" value={formData.indicadoTelefone} onChange={handleChange} required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="indicadoBairro">Bairro do Indicado</Label>
              <Input id="indicadoBairro" placeholder="Bairro do seu amigo" value={formData.indicadoBairro} onChange={handleChange} required />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="indicadoCidade">Cidade do Indicado</Label>
              <Input id="indicadoCidade" placeholder="Cidade do seu amigo" value={formData.indicadoCidade} onChange={handleChange} required />
            </div>
          </CardContent>
        </Card>
        
        <motion.div variants={itemVariants} className="mt-8 flex justify-end">
          <Button type="submit" size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 text-base px-8 py-3 rounded-lg shadow-md" disabled={isLoading}>
            {isLoading ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                Enviando...
              </div>
            ) : (
              <div className="flex items-center justify-center">
                <Send className="mr-2 h-5 w-5" />
                Enviar Indicação
              </div>
            )}
          </Button>
        </motion.div>
      </motion.form>
    </motion.div>
  );
}

export default IndicarAmigoPage;