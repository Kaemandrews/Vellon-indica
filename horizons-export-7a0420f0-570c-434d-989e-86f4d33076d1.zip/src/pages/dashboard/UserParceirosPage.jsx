import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Users2 } from 'lucide-react';

function UserParceirosPage() {
  const [partners, setPartners] = useState([]);

  useEffect(() => {
    const storedPartners = localStorage.getItem('vellonIndica_partners');
    if (storedPartners) {
      setPartners(JSON.parse(storedPartners));
    }
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      <motion.div variants={itemVariants} className="flex items-center gap-3">
        <Users2 className="h-10 w-10 text-primary" />
        <div>
          <h1 className="text-3xl md:text-4xl font-bold">Empresas Parceiras</h1>
          <p className="text-muted-foreground mt-1 text-lg">Conheça os parceiros do programa "Vellon Indica".</p>
        </div>
      </motion.div>

      {partners.length > 0 ? (
        <motion.div 
          variants={containerVariants}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {partners.map((partner) => (
            <motion.div key={partner.id} variants={itemVariants}>
              <Card className="overflow-hidden shadow-lg rounded-xl border-border h-full flex flex-col hover:shadow-2xl transition-shadow duration-300">
                <div className="relative w-full h-48 bg-muted">
                  <img-replace 
                    src={partner.imageUrl || `https://source.unsplash.com/random/400x300?business,company&sig=${partner.id}`} 
                    alt={`Imagem de ${partner.name}`} 
                    className="w-full h-full object-cover" 
                  />
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-xl text-primary">{partner.name}</CardTitle>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-sm text-muted-foreground leading-relaxed">{partner.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      ) : (
        <motion.div variants={itemVariants} className="text-center py-10">
          <Users2 size={48} className="mx-auto text-muted-foreground mb-4" />
          <p className="text-xl text-muted-foreground">Nenhuma empresa parceira cadastrada no momento.</p>
        </motion.div>
      )}
    </motion.div>
  );
}

export default UserParceirosPage;