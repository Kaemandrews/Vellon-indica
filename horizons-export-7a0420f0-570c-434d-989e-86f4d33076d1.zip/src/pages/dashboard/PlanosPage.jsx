import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Check, Wifi, Tv, Music, Play, Film, Zap, Smile, Star, Gamepad2, ShieldCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useToast } from "@/components/ui/use-toast";

const planData = [
  {
    id: 1,
    title: "Internet 300 Mega",
    price: "79,90",
    icon: Wifi,
    iconBg: "bg-sky-100",
    iconColor: "text-sky-600",
    borderColor: "border-sky-500",
    features: [
      "Velocidade de 300 Mega",
      "Ideal para navegação e streaming",
    ],
  },
  {
    id: 2,
    title: "Internet 500 Mega + Deezer",
    price: "109,90",
    icon: Music,
    iconBg: "bg-purple-100",
    iconColor: "text-purple-600",
    borderColor: "border-purple-500",
    features: [
      "Velocidade de 500 Mega",
      "Acesso ao Deezer Premium",
      "Música ilimitada",
    ],
  },
  {
    id: 3,
    title: "Internet 500 Mega + Globoplay (com anúncios)",
    price: "129,90",
    icon: Tv,
    iconBg: "bg-blue-100",
    iconColor: "text-blue-600",
    borderColor: "border-blue-500",
    features: [
      "Velocidade de 500 Mega",
      "Acesso ao Globoplay com anúncios",
      "Filmes e séries",
    ],
  },
  {
    id: 4,
    title: "Internet 500 Mega + Brasileirão Premiere",
    price: "149,90",
    icon: Gamepad2,
    iconBg: "bg-orange-100",
    iconColor: "text-orange-600",
    borderColor: "border-orange-500",
    features: [
      "Velocidade de 500 Mega",
      "Acesso ao Brasileirão Premiere",
      "Jogos ao vivo",
    ],
  },
  {
    id: 5,
    title: "Internet 500 Mega + Globoplay (sem anúncios)",
    price: "169,90",
    icon: Film,
    iconBg: "bg-red-100",
    iconColor: "text-red-600",
    borderColor: "border-red-500",
    features: [
      "Velocidade de 500 Mega",
      "Acesso ao Globoplay sem anúncios",
      "Conteúdo exclusivo",
    ],
  },
  {
    id: 6,
    title: "Internet 600 MB + Max",
    price: "129,90",
    icon: ShieldCheck,
    iconBg: "bg-rose-100",
    iconColor: "text-rose-600",
    borderColor: "border-rose-500",
    features: [
      "Velocidade de 600 Mega",
      "Acesso ao Max (HBO Max)",
      "Grandes sucessos do cinema e séries",
    ],
  },
  {
    id: 7,
    title: "Internet 700 Mega",
    price: "109,90",
    icon: Zap,
    iconBg: "bg-pink-100",
    iconColor: "text-pink-600",
    borderColor: "border-pink-500",
    promotionalText: "Plano promocional Dia das Mães",
    features: [
      "Velocidade de 700 Mega",
      "Ultra velocidade para múltiplos dispositivos",
    ],
  },
  {
    id: 8,
    title: "Internet 500 Mega + Playkids+",
    price: "109,90",
    icon: Smile,
    iconBg: "bg-yellow-100",
    iconColor: "text-yellow-600",
    borderColor: "border-yellow-500",
    features: [
      "Velocidade de 500 Mega",
      "Acesso ao Playkids+",
      "Diversão para crianças",
    ],
  },
  {
    id: 9,
    title: "Internet 700 Mega (Alternativo)",
    price: "119,90",
    icon: Wifi,
    iconBg: "bg-indigo-100",
    iconColor: "text-indigo-600",
    borderColor: "border-indigo-500",
    features: [
      "Velocidade de 700 Mega",
      "Conexão estável e potente",
    ],
  },
];

const PlanCard = ({ plan, onIndicate }) => {
  const IconComponent = plan.icon;
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="h-full"
    >
      <Card className={`shadow-xl rounded-2xl border-2 ${plan.borderColor} h-full flex flex-col overflow-hidden transition-all duration-300 hover:shadow-2xl hover:scale-105`}>
        <CardHeader className="items-center text-center p-6">
          <div className={`p-4 rounded-full ${plan.iconBg} inline-block mb-4`}>
            <IconComponent size={32} className={plan.iconColor} />
          </div>
          <CardTitle className="text-xl font-bold text-gray-800">{plan.title}</CardTitle>
          <div className="my-3">
            <span className="text-4xl font-extrabold text-gray-900">R$ {plan.price}</span>
            <span className="text-md text-gray-500">/mês</span>
          </div>
          {plan.promotionalText && (
            <span className="inline-block bg-pink-500 text-white text-xs font-semibold px-3 py-1 rounded-full my-2">
              <Star size={12} className="inline mr-1 mb-0.5" /> {plan.promotionalText}
            </span>
          )}
        </CardHeader>
        <CardContent className="flex-grow p-6 pt-0">
          <ul className="space-y-2 mb-6">
            {plan.features.map((feature, index) => (
              <li key={index} className="flex items-center text-gray-600">
                <Check size={18} className="text-green-500 mr-2 flex-shrink-0" />
                {feature}
              </li>
            ))}
          </ul>
        </CardContent>
        <div className="p-6 pt-0 mt-auto">
          <Button 
            onClick={() => onIndicate(plan.title)}
            className={`w-full bg-green-500 hover:bg-green-600 text-white font-semibold py-3 rounded-lg text-md shadow-md hover:shadow-lg transition-all duration-200`}
          >
            Indicar este Plano
          </Button>
        </div>
      </Card>
    </motion.div>
  );
};

function PlanosPage() {
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleIndicatePlan = (planName) => {
    toast({
        title: "Plano Selecionado!",
        description: `Você selecionou o plano: ${planName}. Preencha os dados para indicar.`,
    });
    navigate('/dashboard/indicar-amigo', { state: { selectedPlan: planName } });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-10"
    >
      <motion.div 
        initial={{ opacity: 0, y: -30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="text-center"
      >
        <div className="inline-block p-3 bg-green-100 rounded-full mb-4">
            <Wifi size={40} className="text-green-600" />
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-gray-800">Nossos Planos de <span className="text-primary">Internet</span></h1>
        <p className="text-muted-foreground mt-3 text-lg max-w-2xl mx-auto">
          Escolha o plano ideal para você e sua família. Conecte-se com a melhor velocidade!
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {planData.map((plan) => (
          <PlanCard key={plan.id} plan={plan} onIndicate={handleIndicatePlan} />
        ))}
      </div>
    </motion.div>
  );
}

export default PlanosPage;