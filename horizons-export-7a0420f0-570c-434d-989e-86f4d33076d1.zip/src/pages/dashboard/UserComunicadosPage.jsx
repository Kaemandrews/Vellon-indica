import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Bell, CheckCheck } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

function UserComunicadosPage() {
  const [comunicados, setComunicados] = useState([]);
  const [readComunicados, setReadComunicados] = useState(new Set());
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    const storedComunicados = JSON.parse(localStorage.getItem('vellonIndica_comunicados')) || [];
    setComunicados(storedComunicados);

    if (user) {
      const userReadComunicadosKey = `vellonIndica_readComunicados_${user.id}`;
      const storedRead = JSON.parse(localStorage.getItem(userReadComunicadosKey)) || [];
      setReadComunicados(new Set(storedRead));
    }
  }, [user]);

  const markAsRead = (comunicadoId) => {
    if (!user) return;
    const newReadComunicados = new Set(readComunicados);
    newReadComunicados.add(comunicadoId);
    setReadComunicados(newReadComunicados);
    
    const userReadComunicadosKey = `vellonIndica_readComunicados_${user.id}`;
    localStorage.setItem(userReadComunicadosKey, JSON.stringify(Array.from(newReadComunicados)));
    toast({ title: "Comunicado Lido", description: "Marcado como lido." });
  };
  
  const markAllAsRead = () => {
    if (!user) return;
    const allComunicadoIds = comunicados.map(c => c.id);
    const newReadComunicados = new Set(allComunicadoIds);
    setReadComunicados(newReadComunicados);

    const userReadComunicadosKey = `vellonIndica_readComunicados_${user.id}`;
    localStorage.setItem(userReadComunicadosKey, JSON.stringify(Array.from(newReadComunicados)));
    toast({ title: "Todos Lidos", description: "Todos os comunicados foram marcados como lidos." });
  };

  const unreadCount = comunicados.filter(c => !readComunicados.has(c.id)).length;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      <motion.div variants={itemVariants} className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Bell className="h-10 w-10 text-primary" />
          <div>
            <h1 className="text-3xl md:text-4xl font-bold">Comunicados</h1>
            <p className="text-muted-foreground mt-1 text-lg">
              {unreadCount > 0 ? `Você tem ${unreadCount} comunicado(s) não lido(s).` : "Nenhum comunicado novo."}
            </p>
          </div>
        </div>
        {comunicados.length > 0 && unreadCount > 0 && (
           <Button onClick={markAllAsRead} variant="outline" className="border-primary text-primary hover:bg-primary/10">
            <CheckCheck size={18} className="mr-2" /> Marcar Todos como Lidos
          </Button>
        )}
      </motion.div>

      {comunicados.length > 0 ? (
        comunicados.map(comunicado => (
          <motion.div key={comunicado.id} variants={itemVariants}>
            <Card className={`shadow-lg rounded-xl border-border ${readComunicados.has(comunicado.id) ? 'opacity-70 bg-slate-50' : 'bg-background'}`}>
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-xl text-primary">{comunicado.title}</CardTitle>
                  {!readComunicados.has(comunicado.id) && (
                    <Button size="sm" onClick={() => markAsRead(comunicado.id)} variant="ghost" className="text-primary hover:text-primary/80">
                      <CheckCheck size={16} className="mr-1" /> Marcar como lido
                    </Button>
                  )}
                </div>
                <CardDescription>{new Date(comunicado.date).toLocaleString('pt-BR')}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 whitespace-pre-wrap">{comunicado.message}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))
      ) : (
        <motion.div variants={itemVariants} className="text-center py-10">
          <Bell size={48} className="mx-auto text-muted-foreground mb-4" />
          <p className="text-xl text-muted-foreground">Nenhum comunicado disponível no momento.</p>
        </motion.div>
      )}
    </motion.div>
  );
}

export default UserComunicadosPage;