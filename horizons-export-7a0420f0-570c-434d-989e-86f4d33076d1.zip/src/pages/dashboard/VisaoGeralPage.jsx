import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { Settings, BarChart2, Bell, UserCircle, Activity } from 'lucide-react';

function VisaoGeralPage() {
  const { user } = useAuth();

  const statsCards = [
    { title: "Meu Perfil", value: user?.name || "Usuário Teste", subValue: user?.email || "user@example.com", icon: UserCircle, color: "text-blue-500", bgColor: "bg-blue-50" },
    { title: "Total de Indicações", value: "25", subValue: "+5 esta semana", icon: Activity, color: "text-green-500", bgColor: "bg-green-50" },
    { title: "Indicações Convertidas", value: "10", subValue: "40% de conversão", icon: BarChart2, color: "text-purple-500", bgColor: "bg-purple-50" },
    { title: "Notificações", value: "3 Novas", subValue: "Verifique agora", icon: Bell, color: "text-orange-500", bgColor: "bg-orange-50" },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100
      }
    }
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      <motion.div variants={itemVariants}>
        <h1 className="text-3xl md:text-4xl font-bold">
          Visão Geral
        </h1>
        <p className="text-muted-foreground mt-1 text-lg">
          Bem-vindo de volta, <span className="text-primary font-semibold">{user?.name || 'Usuário'}</span>!
        </p>
      </motion.div>

      <motion.div 
        variants={containerVariants}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 xl:grid-cols-4 gap-6"
      >
        {statsCards.map((card, index) => (
          <motion.div key={index} variants={itemVariants}>
            <Card className={`h-full shadow-lg hover:shadow-xl transition-all duration-300 border-transparent rounded-xl overflow-hidden ${card.bgColor}`}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 pt-6 px-6">
                <CardTitle className={`text-sm font-medium ${card.color}`}>{card.title}</CardTitle>
                <card.icon className={`h-6 w-6 ${card.color}`} />
              </CardHeader>
              <CardContent className="px-6 pb-6">
                <div className={`text-3xl font-bold ${card.color}`}>{card.value}</div>
                <p className="text-xs text-muted-foreground pt-1">
                  {card.subValue}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="border-border shadow-xl rounded-xl">
          <CardHeader className="pb-4">
            <CardTitle className="text-primary text-xl">Ações Rápidas</CardTitle>
            <CardDescription>Acesse as funcionalidades mais usadas.</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Button variant="outline" className="w-full flex items-center justify-center gap-2 py-6 text-base border-primary text-primary hover:bg-primary/10 rounded-lg">
              <Settings className="h-5 w-5" />
              Configurações da Conta
            </Button>
            <Button variant="outline" className="w-full flex items-center justify-center gap-2 py-6 text-base border-primary text-primary hover:bg-primary/10 rounded-lg">
              <UserCircle className="h-5 w-5" />
              Editar Perfil
            </Button>
             <Button variant="default" className="w-full sm:col-span-2 flex items-center justify-center gap-2 py-6 text-base bg-primary text-primary-foreground hover:bg-primary/90 rounded-lg">
              Ver todas as indicações
            </Button>
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}

export default VisaoGeralPage;