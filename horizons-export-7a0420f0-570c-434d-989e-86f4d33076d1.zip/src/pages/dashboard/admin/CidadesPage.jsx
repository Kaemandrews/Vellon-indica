import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { MapPin, Save, PlusCircle, Trash2 } from 'lucide-react';

const initialCities = [
  { id: 1, name: "Santa Izabel" },
  { id: 2, name: "Santo Antônio do Tauá" },
  { id: 3, name: "Castanhal" },
  { id: 4, name: "Curuçá" },
  { id: 5, name: "Marapanim" },
  { id: 6, name: "Bujaru" },
  { id: 7, name: "Nova Timboteua" },
];

function CidadesPage() {
  const [cities, setCities] = useState([]);
  const [newCityName, setNewCityName] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const storedCities = localStorage.getItem('vellonIndica_cities');
    if (storedCities) {
      setCities(JSON.parse(storedCities));
    } else {
      setCities(initialCities);
      localStorage.setItem('vellonIndica_cities', JSON.stringify(initialCities));
    }
  }, []);

  const handleSaveCities = () => {
    localStorage.setItem('vellonIndica_cities', JSON.stringify(cities));
    toast({
      title: "Cidades Salvas!",
      description: "A lista de cidades participantes foi atualizada.",
    });
  };

  const handleAddCity = () => {
    if (newCityName.trim() === '') {
      toast({ variant: "destructive", title: "Erro", description: "O nome da cidade não pode estar vazio." });
      return;
    }
    const newCity = { id: Date.now(), name: newCityName.trim() };
    const updatedCities = [...cities, newCity];
    setCities(updatedCities);
    setNewCityName('');
    localStorage.setItem('vellonIndica_cities', JSON.stringify(updatedCities)); // Salva imediatamente ao adicionar
    toast({ title: "Cidade Adicionada", description: `${newCity.name} foi incluída na lista.` });
  };

  const handleDeleteCity = (id) => {
    const updatedCities = cities.filter(city => city.id !== id);
    setCities(updatedCities);
    localStorage.setItem('vellonIndica_cities', JSON.stringify(updatedCities)); // Salva imediatamente ao remover
    toast({ title: "Cidade Removida", description: "A cidade foi excluída da lista." });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      <motion.div variants={itemVariants} className="flex items-center gap-3">
        <MapPin className="h-10 w-10 text-primary" />
        <div>
          <h1 className="text-3xl md:text-4xl font-bold">Gerenciar Cidades Participantes</h1>
          <p className="text-muted-foreground mt-1 text-lg">Adicione ou remova cidades onde a promoção está ativa.</p>
        </div>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="shadow-xl rounded-xl border-border">
          <CardHeader className="bg-slate-50/50 border-b p-4 md:p-6">
            <CardTitle className="text-xl text-primary">Cidades Ativas</CardTitle>
            <CardDescription>Lista de cidades onde a promoção é válida.</CardDescription>
          </CardHeader>
          <CardContent className="p-6 space-y-3">
            {cities.map((city) => (
              <motion.div 
                key={city.id} 
                variants={itemVariants}
                className="flex items-center justify-between p-3 border rounded-lg bg-background hover:bg-slate-50/50"
              >
                <div className="flex items-center gap-2">
                  <MapPin size={18} className="text-primary" />
                  <span className="text-md">{city.name}</span>
                </div>
                <Button variant="ghost" size="icon" onClick={() => handleDeleteCity(city.id)} className="text-destructive hover:bg-destructive/10">
                  <Trash2 size={18} />
                </Button>
              </motion.div>
            ))}
            {cities.length === 0 && (
              <p className="text-muted-foreground text-center py-4">Nenhuma cidade cadastrada.</p>
            )}
          </CardContent>
        </Card>
      </motion.div>
      
      <motion.div variants={itemVariants}>
        <Card className="shadow-xl rounded-xl border-border">
          <CardHeader className="bg-slate-50/50 border-b p-4 md:p-6">
            <CardTitle className="text-xl text-primary">Adicionar Nova Cidade</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <Input 
                placeholder="Nome da nova cidade" 
                value={newCityName} 
                onChange={(e) => setNewCityName(e.target.value)}
                className="flex-grow"
              />
              <Button onClick={handleAddCity} className="bg-primary hover:bg-primary/90">
                <PlusCircle size={18} className="mr-2" /> Adicionar Cidade
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants} className="flex justify-end">
        <Button size="lg" onClick={handleSaveCities} className="bg-green-600 hover:bg-green-700 text-white">
          <Save size={20} className="mr-2" /> Salvar Alterações nas Cidades
        </Button>
      </motion.div>
    </motion.div>
  );
}

export default CidadesPage;