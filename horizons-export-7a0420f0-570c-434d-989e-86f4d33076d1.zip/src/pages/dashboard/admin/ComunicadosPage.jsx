import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { Megaphone, Send, Trash2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

function AdminComunicadosPage() {
  const [comunicados, setComunicados] = useState([]);
  const [newComunicado, setNewComunicado] = useState({ title: '', message: '' });
  const { toast } = useToast();
  const { fetchLatestComunicado } = useAuth();

  useEffect(() => {
    const storedComunicados = localStorage.getItem('vellonIndica_comunicados');
    if (storedComunicados) {
      setComunicados(JSON.parse(storedComunicados));
    }
  }, []);

  const handleSendComunicado = () => {
    if (!newComunicado.title.trim() || !newComunicado.message.trim()) {
      toast({ variant: "destructive", title: "Erro", description: "Título e mensagem são obrigatórios." });
      return;
    }
    const comunicadoToSend = { 
      id: Date.now(), 
      title: newComunicado.title.trim(),
      message: newComunicado.message.trim(),
      date: new Date().toISOString(),
      readBy: [] 
    };
    const updatedComunicados = [comunicadoToSend, ...comunicados];
    setComunicados(updatedComunicados);
    localStorage.setItem('vellonIndica_comunicados', JSON.stringify(updatedComunicados));
    setNewComunicado({ title: '', message: '' });
    fetchLatestComunicado(); // Atualiza o letreiro
    toast({
      title: "Comunicado Enviado!",
      description: "Sua mensagem foi enviada para os usuários.",
    });
  };

  const handleDeleteComunicado = (id) => {
    const updatedComunicados = comunicados.filter(c => c.id !== id);
    setComunicados(updatedComunicados);
    localStorage.setItem('vellonIndica_comunicados', JSON.stringify(updatedComunicados));
    fetchLatestComunicado(); // Atualiza o letreiro se o último for removido
    toast({ title: "Comunicado Removido" });
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      <motion.div variants={itemVariants} className="flex items-center gap-3">
        <Megaphone className="h-10 w-10 text-primary" />
        <div>
          <h1 className="text-3xl md:text-4xl font-bold">Enviar Comunicados</h1>
          <p className="text-muted-foreground mt-1 text-lg">Envie mensagens e avisos para todos os usuários.</p>
        </div>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="shadow-xl rounded-xl border-border">
          <CardHeader className="bg-slate-50/50 border-b p-4 md:p-6">
            <CardTitle className="text-xl text-primary">Novo Comunicado</CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <Input 
              placeholder="Título do Comunicado" 
              value={newComunicado.title}
              onChange={(e) => setNewComunicado({...newComunicado, title: e.target.value})}
            />
            <Textarea 
              placeholder="Digite sua mensagem aqui..." 
              value={newComunicado.message}
              onChange={(e) => setNewComunicado({...newComunicado, message: e.target.value})}
              className="min-h-[120px]"
            />
            <div className="flex justify-end">
              <Button onClick={handleSendComunicado} className="bg-primary hover:bg-primary/90">
                <Send size={18} className="mr-2" /> Enviar Comunicado
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="shadow-xl rounded-xl border-border">
          <CardHeader className="bg-slate-50/50 border-b p-4 md:p-6">
            <CardTitle className="text-xl text-primary">Histórico de Comunicados</CardTitle>
            <CardDescription>Comunicados enviados anteriormente.</CardDescription>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            {comunicados.length > 0 ? comunicados.map(comunicado => (
              <motion.div key={comunicado.id} variants={itemVariants} className="p-4 border rounded-lg bg-background">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-semibold text-lg">{comunicado.title}</h3>
                    <p className="text-sm text-muted-foreground">{new Date(comunicado.date).toLocaleString('pt-BR')}</p>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => handleDeleteComunicado(comunicado.id)} className="text-destructive hover:bg-destructive/10">
                    <Trash2 size={18} />
                  </Button>
                </div>
                <p className="mt-2 text-gray-700 whitespace-pre-wrap">{comunicado.message}</p>
              </motion.div>
            )) : (
              <p className="text-muted-foreground text-center py-4">Nenhum comunicado enviado ainda.</p>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}

export default AdminComunicadosPage;