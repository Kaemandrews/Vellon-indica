import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { Building, Save, PlusCircle, Trash2, ImagePlus } from 'lucide-react';

const initialPartners = [
  { id: 1, name: "Parceiro Tech", description: "Soluções em tecnologia e inovação.", imageUrl: "https://images.unsplash.com/photo-1517048676732-d65bc937f952?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8b2ZmaWNlJTIwdGVjaHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=300&q=60" },
  { id: 2, name: "Serviços Locais", description: "Conectando você aos melhores serviços da sua região.", imageUrl: "https://images.unsplash.com/photo-1556761175-5973dc0f32e7?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8c2VydmljZXMlMjBsb2NhbHxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=300&q=60" },
  { id: 3, name: "Varejo Amigo", description: "As melhores ofertas e produtos perto de você.", imageUrl: "https://images.unsplash.com/photo-1528698827591-e19ccd7e23dd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmV0YWlsJTIwc3RvcmV8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=300&q=60" },
  { id: 4, name: "Diversão Garantida", description: "Opções de lazer e entretenimento para toda a família.", imageUrl: "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Y29uY2VydCUyMGZ1bnxlbnwwfHwwfHx8MA%3D%3D&auto=format&fit=crop&w=300&q=60" },
  { id: 5, name: "Educa Mais", description: "Invista no seu futuro com nossos cursos e treinamentos.", imageUrl: "https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8ZWR1Y2F0aW9ufGVufDB8fDB8fHww&auto=format&fit=crop&w=300&q=60" },
  { id: 6, name: "Sabor & Cia", description: "Delícias gastronômicas para todos os paladares.", imageUrl: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmVzdGF1cmFudCUyMGZvb2R8ZW58MHx8MHx8fDA%3D&auto=format&fit=crop&w=300&q=60" },
];

function ParceirosPage() {
  const [partners, setPartners] = useState([]);
  const [newPartner, setNewPartner] = useState({ name: '', description: '', imageUrl: '' });
  const { toast } = useToast();

  useEffect(() => {
    const storedPartners = localStorage.getItem('vellonIndica_partners');
    if (storedPartners) {
      setPartners(JSON.parse(storedPartners));
    } else {
      setPartners(initialPartners);
      localStorage.setItem('vellonIndica_partners', JSON.stringify(initialPartners));
    }
  }, []);

  const handleSavePartners = () => {
    localStorage.setItem('vellonIndica_partners', JSON.stringify(partners));
    toast({
      title: "Parceiros Salvos!",
      description: "A lista de empresas parceiras foi atualizada.",
    });
  };

  const handleAddPartner = () => {
    if (!newPartner.name.trim() || !newPartner.description.trim()) {
      toast({ variant: "destructive", title: "Erro", description: "Nome e descrição do parceiro são obrigatórios." });
      return;
    }
    const partnerToAdd = { ...newPartner, id: Date.now(), imageUrl: newPartner.imageUrl || `https://source.unsplash.com/random/300x200?company&sig=${Date.now()}` };
    const updatedPartners = [...partners, partnerToAdd];
    setPartners(updatedPartners);
    setNewPartner({ name: '', description: '', imageUrl: '' });
    localStorage.setItem('vellonIndica_partners', JSON.stringify(updatedPartners));
    toast({ title: "Parceiro Adicionado", description: `${partnerToAdd.name} foi incluído na lista.` });
  };

  const handleDeletePartner = (id) => {
    const updatedPartners = partners.filter(partner => partner.id !== id);
    setPartners(updatedPartners);
    localStorage.setItem('vellonIndica_partners', JSON.stringify(updatedPartners));
    toast({ title: "Parceiro Removido", description: "O parceiro foi excluído da lista." });
  };
  
  const handleInputChange = (id, field, value) => {
    setPartners(partners.map(p => p.id === id ? { ...p, [field]: value } : p));
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      <motion.div variants={itemVariants} className="flex items-center gap-3">
        <Building className="h-10 w-10 text-primary" />
        <div>
          <h1 className="text-3xl md:text-4xl font-bold">Gerenciar Empresas Parceiras</h1>
          <p className="text-muted-foreground mt-1 text-lg">Adicione ou edite informações sobre os parceiros.</p>
        </div>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="shadow-xl rounded-xl border-border">
          <CardHeader className="bg-slate-50/50 border-b p-4 md:p-6">
            <CardTitle className="text-xl text-primary">Adicionar Novo Parceiro</CardTitle>
          </CardHeader>
          <CardContent className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input placeholder="Nome do Parceiro" value={newPartner.name} onChange={(e) => setNewPartner({...newPartner, name: e.target.value})} />
            <Input placeholder="URL da Imagem (opcional)" value={newPartner.imageUrl} onChange={(e) => setNewPartner({...newPartner, imageUrl: e.target.value})} />
            <Textarea placeholder="Descrição do Parceiro" value={newPartner.description} onChange={(e) => setNewPartner({...newPartner, description: e.target.value})} className="md:col-span-2 min-h-[80px]" />
            <div className="md:col-span-2 flex justify-end">
              <Button onClick={handleAddPartner} className="bg-primary hover:bg-primary/90">
                <PlusCircle size={18} className="mr-2" /> Adicionar Parceiro
              </Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="shadow-xl rounded-xl border-border">
          <CardHeader className="bg-slate-50/50 border-b p-4 md:p-6">
            <CardTitle className="text-xl text-primary">Parceiros Cadastrados</CardTitle>
            <CardDescription>Edite os parceiros existentes.</CardDescription>
          </CardHeader>
          <CardContent className="p-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {partners.map((partner) => (
              <motion.div key={partner.id} variants={itemVariants}>
                <Card className="overflow-hidden h-full flex flex-col">
                  <div className="relative w-full h-40 bg-muted">
                    <img-replace src={partner.imageUrl} alt={partner.name} className="w-full h-full object-cover" />
                  </div>
                  <CardContent className="p-4 flex-grow flex flex-col">
                    <Input 
                      value={partner.name} 
                      onChange={(e) => handleInputChange(partner.id, 'name', e.target.value)}
                      className="text-lg font-semibold mb-2"
                    />
                    <Textarea 
                      value={partner.description} 
                      onChange={(e) => handleInputChange(partner.id, 'description', e.target.value)}
                      className="text-sm text-muted-foreground mb-3 flex-grow min-h-[80px] resize-none"
                    />
                     <Input 
                      value={partner.imageUrl} 
                      onChange={(e) => handleInputChange(partner.id, 'imageUrl', e.target.value)}
                      className="text-xs mb-3"
                      placeholder="URL da Imagem"
                    />
                    <Button variant="ghost" size="sm" onClick={() => handleDeletePartner(partner.id)} className="text-destructive hover:bg-destructive/10 self-start mt-auto">
                      <Trash2 size={16} className="mr-1" /> Remover
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
            {partners.length === 0 && (
              <p className="text-muted-foreground text-center py-4 md:col-span-3">Nenhum parceiro cadastrado.</p>
            )}
          </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants} className="flex justify-end">
        <Button size="lg" onClick={handleSavePartners} className="bg-green-600 hover:bg-green-700 text-white">
          <Save size={20} className="mr-2" /> Salvar Alterações nos Parceiros
        </Button>
      </motion.div>
    </motion.div>
  );
}

export default ParceirosPage;