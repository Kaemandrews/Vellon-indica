import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Gavel, Save, PlusCircle, Trash2 } from 'lucide-react';

const initialRules = [
  { id: 1, text: "A promoção 'Vellon Indica' é válida por tempo limitado. Consulte o regulamento." },
  { id: 2, text: "Para cada indicação válida, o indicador receberá prêmio no Valor de R$ 35,00." },
  { id: 3, text: "Uma indicação é considerada válida quando o indicado contrata qualquer serviço." },
  { id: 4, text: "Os prêmios serão pagos via Pix em até 15 dias úteis após a validação da indicação." },
  { id: 5, text: "Não há limite para o número de indicações, indique quantos amigos quiser!" },
];

function RegrasPage() {
  const [rules, setRules] = useState([]);
  const [newRuleText, setNewRuleText] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    const storedRules = localStorage.getItem('vellonIndica_rules');
    if (storedRules) {
      setRules(JSON.parse(storedRules));
    } else {
      setRules(initialRules);
      localStorage.setItem('vellonIndica_rules', JSON.stringify(initialRules));
    }
  }, []);

  const handleSaveRules = () => {
    localStorage.setItem('vellonIndica_rules', JSON.stringify(rules));
    toast({
      title: "Regras Salvas!",
      description: "As regras da promoção foram atualizadas com sucesso.",
    });
  };

  const handleAddRule = () => {
    if (newRuleText.trim() === '') {
      toast({ variant: "destructive", title: "Erro", description: "O texto da regra não pode estar vazio." });
      return;
    }
    const newRule = { id: Date.now(), text: newRuleText.trim() };
    const updatedRules = [...rules, newRule];
    setRules(updatedRules);
    setNewRuleText('');
    localStorage.setItem('vellonIndica_rules', JSON.stringify(updatedRules));
    toast({ title: "Regra Adicionada", description: "Nova regra incluída." });
  };

  const handleDeleteRule = (id) => {
    const updatedRules = rules.filter(rule => rule.id !== id);
    setRules(updatedRules);
    localStorage.setItem('vellonIndica_rules', JSON.stringify(updatedRules));
    toast({ title: "Regra Removida", description: "A regra foi excluída." });
  };
  
  const handleRuleTextChange = (id, newText) => {
    const updatedRules = rules.map(rule => rule.id === id ? { ...rule, text: newText } : rule);
    setRules(updatedRules);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      <motion.div variants={itemVariants} className="flex items-center gap-3">
        <Gavel className="h-10 w-10 text-primary" />
        <div>
          <h1 className="text-3xl md:text-4xl font-bold">Gerenciar Regras da Promoção</h1>
          <p className="text-muted-foreground mt-1 text-lg">Defina e atualize as regras do programa "Indica Aí".</p>
        </div>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="shadow-xl rounded-xl border-border">
          <CardHeader className="bg-slate-50/50 border-b p-4 md:p-6">
            <CardTitle className="text-xl text-primary">Regras Atuais</CardTitle>
            <CardDescription>Edite, adicione ou remova regras abaixo.</CardDescription>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            {rules.map((rule, index) => (
              <motion.div key={rule.id} variants={itemVariants} className="flex items-start gap-3 p-3 border rounded-lg bg-background">
                <span className="text-primary font-semibold pt-2">{index + 1}.</span>
                <Textarea 
                  value={rule.text} 
                  onChange={(e) => handleRuleTextChange(rule.id, e.target.value)}
                  className="flex-grow resize-none min-h-[60px]"
                  rows={Math.max(2, Math.ceil(rule.text.length / 50))} 
                />
                <Button variant="ghost" size="icon" onClick={() => handleDeleteRule(rule.id)} className="text-destructive hover:bg-destructive/10 mt-1">
                  <Trash2 size={18} />
                </Button>
              </motion.div>
            ))}
             <div className="pt-4 space-y-2">
              <Label htmlFor="newRuleText" className="text-md font-semibold">Adicionar Nova Regra</Label>
              <div className="flex items-start gap-3">
                <Textarea 
                  id="newRuleText"
                  placeholder="Digite o texto da nova regra..." 
                  value={newRuleText} 
                  onChange={(e) => setNewRuleText(e.target.value)}
                  className="flex-grow resize-none min-h-[60px]"
                  rows={2}
                />
                <Button onClick={handleAddRule} className="bg-primary hover:bg-primary/90 mt-1">
                  <PlusCircle size={18} className="mr-2" /> Adicionar
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div variants={itemVariants} className="flex justify-end">
        <Button size="lg" onClick={handleSaveRules} className="bg-green-600 hover:bg-green-700 text-white">
          <Save size={20} className="mr-2" /> Salvar Todas as Alterações
        </Button>
      </motion.div>
    </motion.div>
  );
}

export default RegrasPage;