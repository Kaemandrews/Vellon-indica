import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ScrollText } from 'lucide-react';

function UserRegrasPage() {
  const [rules, setRules] = useState([]);

  useEffect(() => {
    const storedRules = localStorage.getItem('vellonIndica_rules');
    if (storedRules) {
      setRules(JSON.parse(storedRules));
    } else {
      // Fallback se não houver regras salvas (idealmente, o admin já teria salvo algumas)
      setRules([{ id: 0, text: "Nenhuma regra cadastrada no momento. Consulte o administrador." }]);
    }
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { type: 'spring', stiffness: 100 } }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-8"
    >
      <motion.div variants={itemVariants} className="flex items-center gap-3">
        <ScrollText className="h-10 w-10 text-primary" />
        <div>
          <h1 className="text-3xl md:text-4xl font-bold">Regras da Promoção</h1>
          <p className="text-muted-foreground mt-1 text-lg">Conheça as regras do programa "Vellon Indica".</p>
        </div>
      </motion.div>

      <motion.div variants={itemVariants}>
        <Card className="shadow-xl rounded-xl border-border">
          <CardHeader className="bg-slate-50/50 border-b p-4 md:p-6">
            <CardTitle className="text-xl text-primary">Regulamento</CardTitle>
            <CardDescription>Leia atentamente as regras abaixo.</CardDescription>
          </CardHeader>
          <CardContent className="p-6 space-y-3">
            {rules.length > 0 ? (
              rules.map((rule, index) => (
                <motion.div 
                  key={rule.id} 
                  variants={itemVariants} 
                  className="flex items-start gap-3 p-3 border-l-4 border-primary bg-primary/5 rounded-r-lg"
                >
                  <span className="text-primary font-semibold pt-0.5">{index + 1}.</span>
                  <p className="text-gray-700 leading-relaxed">{rule.text}</p>
                </motion.div>
              ))
            ) : (
              <p className="text-muted-foreground text-center py-4">Nenhuma regra disponível no momento.</p>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  );
}

export default UserRegrasPage;