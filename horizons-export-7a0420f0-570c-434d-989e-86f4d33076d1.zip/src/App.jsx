import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import Layout from '@/components/Layout';
import HomePage from '@/pages/HomePage';
import DashboardPage from '@/pages/DashboardPage';
import ProtectedRoute from '@/components/ProtectedRoute';
import AdminRoute from '@/components/AdminRoute';
import LoginPage from '@/pages/LoginPage';
import RegisterPage from '@/pages/RegisterPage';
import { AuthProvider } from '@/contexts/AuthContext';
import VisaoGeralPage from '@/pages/dashboard/VisaoGeralPage';
import IndicacoesPage from '@/pages/dashboard/IndicacoesPage';
import IndicarAmigoPage from '@/pages/dashboard/IndicarAmigoPage';
import AdminRegrasPage from '@/pages/dashboard/admin/RegrasPage';
import AdminCidadesPage from '@/pages/dashboard/admin/CidadesPage';
import AdminParceirosPage from '@/pages/dashboard/admin/ParceirosPage';
import AdminComunicadosPage from '@/pages/dashboard/admin/ComunicadosPage';
import UserComunicadosPage from '@/pages/dashboard/UserComunicadosPage';
import UserRegrasPage from '@/pages/dashboard/UserRegrasPage';
import UserCidadesPage from '@/pages/dashboard/UserCidadesPage';
import UserParceirosPage from '@/pages/dashboard/UserParceirosPage';
import PlanosPage from '@/pages/dashboard/PlanosPage';


function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<HomePage />} />
          <Route path="login" element={<LoginPage />} />
          <Route path="register" element={<RegisterPage />} />
          <Route 
            path="dashboard"
            element={
              <ProtectedRoute>
                <DashboardPage />
              </ProtectedRoute>
            }
          >
            <Route index element={<VisaoGeralPage />} />
            <Route path="indicacoes" element={<IndicacoesPage />} />
            <Route path="indicar-amigo" element={<IndicarAmigoPage />} />
            <Route path="comunicados" element={<UserComunicadosPage />} />
            <Route path="regras" element={<UserRegrasPage />} />
            <Route path="cidades-participantes" element={<UserCidadesPage />} />
            <Route path="empresas-parceiras" element={<UserParceirosPage />} />
            <Route path="planos" element={<PlanosPage />} />

            {/* Admin Routes */}
            <Route path="admin/regras" element={<AdminRoute><AdminRegrasPage /></AdminRoute>} />
            <Route path="admin/cidades" element={<AdminRoute><AdminCidadesPage /></AdminRoute>} />
            <Route path="admin/parceiros" element={<AdminRoute><AdminParceirosPage /></AdminRoute>} />
            <Route path="admin/comunicados" element={<AdminRoute><AdminComunicadosPage /></AdminRoute>} />
          </Route>
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
      <Toaster />
    </AuthProvider>
  );
}

export default App;