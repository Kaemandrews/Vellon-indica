import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-gray-100 border-t border-border text-gray-700">
      <div className="container mx-auto px-4 py-8 text-center">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="mb-4"
        >
          <Link to="/" className="flex items-center justify-center space-x-2">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-sm">
              VI
            </div>
            <span className="text-lg font-bold text-primary">Vellon Indica</span>
          </Link>
        </motion.div>
        <p className="text-sm">
          &copy; {currentYear} Vellon Telecom. Todos os direitos reservados.
        </p>
        <p className="text-sm mt-2">
          Entre em contato via <a href="mailto:contato@vellontelecom.com.br" className="link-primary font-medium">email</a> ou <a href="tel:+550000000000" className="link-primary font-medium">telefone</a>.
        </p>
        <p className="text-xs text-gray-500 mt-4">
          Criado com <span className="text-primary font-semibold">Hostinger Horizons</span>
        </p>
      </div>
    </footer>
  );
}

export default Footer;