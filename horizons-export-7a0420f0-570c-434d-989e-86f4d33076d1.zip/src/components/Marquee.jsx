import React from 'react';
import { motion } from 'framer-motion';

const Marquee = ({ text, backgroundColor = 'bg-primary/10', textColor = 'text-primary' }) => {
  if (!text) return null;

  const marqueeVariants = {
    animate: {
      x: ['100%', '-100%'],
      transition: {
        x: {
          repeat: Infinity,
          repeatType: 'loop',
          duration: 20, 
          ease: 'linear',
        },
      },
    },
  };

  return (
    <div className={`w-full overflow-x-hidden ${backgroundColor} py-1.5`}>
      <motion.div
        className="whitespace-nowrap"
        variants={marqueeVariants}
        animate="animate"
      >
        <span className={`text-sm font-medium ${textColor}`}>{text}</span>
      </motion.div>
    </div>
  );
};

export default Marquee;