import React, { useState, useEffect } from 'react';
import { Link, useNavigate, NavLink, useLocation } from 'react-router-dom';
import { Menu, X, LogIn, LogOut, LayoutDashboard, Users, HeartHandshake as Handshake, UserPlus, Bell, ShieldCheck, Gavel, MapPin, Building, Megaphone, ScrollText, Users2, Info, Wifi } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import Marquee from '@/components/Marquee';

function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { user, logout, isAuthenticated, adminHasNewIndications, userHasNewComunicados, latestComunicado } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    logout();
    navigate('/');
    setIsOpen(false);
  };

  const navLinkClass = "text-foreground hover:text-primary transition-colors px-3 py-2 rounded-md text-sm font-medium flex items-center gap-1.5 relative";
  const activeNavLinkClass = "text-primary bg-primary/10";

  const commonNavLinks = [
    { to: "/", text: "Início", exact: true },
  ];

  const authenticatedNavLinks = [
    { to: "/dashboard", text: "Visão Geral", icon: LayoutDashboard, exact: true, notification: false },
    { to: "/dashboard/indicacoes", text: "Indicações", icon: Handshake, notification: user?.isAdmin && adminHasNewIndications },
    { to: "/dashboard/indicar-amigo", text: "Indicar Amigo", icon: UserPlus, notification: false },
    { to: "/dashboard/planos", text: "Nossos Planos", icon: Wifi, notification: false },
    { to: "/dashboard/comunicados", text: "Comunicados", icon: Bell, notification: !user?.isAdmin && userHasNewComunicados },
    { to: "/dashboard/regras", text: "Regras", icon: ScrollText, notification: false },
    { to: "/dashboard/cidades-participantes", text: "Cidades", icon: MapPin, notification: false },
    { to: "/dashboard/empresas-parceiras", text: "Parceiros", icon: Users2, notification: false },
  ];

  const adminNavLinks = [
    { to: "/dashboard/admin/regras", text: "Ger. Regras", icon: Gavel, notification: false },
    { to: "/dashboard/admin/cidades", text: "Ger. Cidades", icon: Info, notification: false },
    { to: "/dashboard/admin/parceiros", text: "Ger. Parceiros", icon: Building, notification: false },
    { to: "/dashboard/admin/comunicados", text: "Enviar Comunicado", icon: Megaphone, notification: false },
  ];

  const getNavLinks = () => {
    let links = [...commonNavLinks];
    if (isAuthenticated) {
      links = [...links, ...authenticatedNavLinks];
      if (user?.isAdmin) {
        links = [...links, ...adminNavLinks];
      }
    }
    return links;
  };
  
  const allNavLinks = getNavLinks();

  return (
    <nav className="sticky top-0 z-50 bg-card/90 backdrop-blur-md border-b border-border shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold text-xl"
            >
              {user?.isAdmin ? <ShieldCheck size={20}/> : 'VI'}
            </motion.div>
            <motion.span
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="text-xl font-bold text-primary"
            >
              Vellon Indica
            </motion.span>
          </Link>

          <div className="hidden md:flex items-center space-x-1">
            {allNavLinks.map(link => (
              <NavLink 
                key={link.to}
                to={link.to} 
                className={({ isActive }) => `${navLinkClass} ${isActive && (link.exact ? location.pathname === link.to : location.pathname.startsWith(link.to)) ? activeNavLinkClass : ''}`}
                end={link.exact}
              >
                {link.icon && <link.icon className="h-4 w-4" />}
                {link.text}
                {link.notification && <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse"></span>}
              </NavLink>
            ))}
          </div>
          
          <div className="hidden md:flex items-center space-x-2">
             {isAuthenticated ? (
              <Button variant="outline" onClick={handleLogout} size="sm" className="border-primary text-primary hover:bg-primary/10">
                <LogOut className="h-4 w-4 mr-2" />
                Sair
              </Button>
            ) : (
              <Button onClick={() => navigate('/login')} size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
                <LogIn className="h-4 w-4 mr-2" />
                Login
              </Button>
            )}
          </div>

          <button
            className="md:hidden text-foreground hover:text-primary"
            onClick={() => setIsOpen(!isOpen)}
            aria-label={isOpen ? "Fechar menu" : "Abrir menu"}
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>
      {latestComunicado && (
        <Marquee text={latestComunicado.title + ": " + latestComunicado.message} />
      )}

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="md:hidden bg-card border-t border-border shadow-lg"
          >
            <div className="container mx-auto px-4 py-3 flex flex-col space-y-2">
              {allNavLinks.map(link => (
                <NavLink 
                  key={`mobile-${link.to}`}
                  to={link.to} 
                  className={({ isActive }) => `py-2 px-3 block rounded-md text-foreground hover:bg-primary/10 hover:text-primary transition-colors flex items-center gap-2 relative ${isActive && (link.exact ? location.pathname === link.to : location.pathname.startsWith(link.to)) ? activeNavLinkClass : ''}`}
                  onClick={() => setIsOpen(false)}
                  end={link.exact}
                >
                  {link.icon && <link.icon className="h-4 w-4" />}
                  {link.text}
                  {link.notification && <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse"></span>}
                </NavLink>
              ))}
              {isAuthenticated ? (
                <Button variant="outline" onClick={handleLogout} className="w-full justify-start mt-2 border-primary text-primary hover:bg-primary/10">
                  <LogOut className="h-4 w-4 mr-2" />
                  Sair
                </Button>
              ) : (
                <Button onClick={() => { navigate('/login'); setIsOpen(false); }} className="w-full justify-start mt-2 bg-primary text-primary-foreground hover:bg-primary/90">
                  <LogIn className="h-4 w-4 mr-2" />
                  Login
                </Button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

export default Navbar;